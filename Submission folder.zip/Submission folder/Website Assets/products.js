document.addEventListener("DOMContentLoaded", function () {
    const orderButton = document.getElementById("order-button");
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const totalPriceDisplay = document.querySelector('#total-price');
    let cart = [];

    orderButton.addEventListener('click', function (event) {
        event.preventDefault();

        const fName = document.getElementById("FName").value;
        const lName = document.getElementById("LName").value;
        const streetAddress = document.getElementById("Street_Address").value;
        const city = document.getElementById("City").value;
        const country = document.getElementById("Country").value;
        const checkboxes2 = document.querySelectorAll("input[type=checkbox]:checked");

        if (fName && lName && streetAddress && city && country && checkboxes2.length > 0) {
            calculateTotalPrice();
            alert("Order placed successfully!");
        } else {
            alert("Please fill out all required fields and select at least one product.");
        }
    });

    checkboxes.forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            updateCart(checkbox);
        });
    });

    function updateCart(checkbox) {
        const price = parseFloat(checkbox.getAttribute('data-price'));
        const quantity = parseFloat(checkbox.getAttribute('data-quantity'));

        if (checkbox.checked) {
            cart.push({ price, quantity });
        } else {
            cart = cart.filter(item => item.price !== price);
        }
    }

    function calculateTotalPrice() {
        let totalPrice = 0;
        cart.forEach(item => {
            totalPrice += item.price;
        });

        checkboxes.forEach(checkbox => {
            checkbox.style.display = 'none';
        });

        totalPriceDisplay.textContent = 'Total Price: $' + totalPrice;
    }


    function loadAndPopulateSavedAddress(addressIndex) {
        const savedAddresses = JSON.parse(localStorage.getItem('addresses'));

        if (savedAddresses) {
            for (let i = 0; i < savedAddresses.length; i++) {
                if (i === addressIndex) {
                    const address = savedAddresses[i];
                   
                    document.getElementById("Street_Address").value = address.Street_Address;
                    document.getElementById("City").value = address.City;
                    document.getElementById("Country").value = address.Country;
                    break;
                }
            }
        }
    }

    document.getElementById('use-saved-address-1').addEventListener('click', function () {
        loadAndPopulateSavedAddress(0);
    });

    document.getElementById('use-saved-address-2').addEventListener('click', function () {
        loadAndPopulateSavedAddress(1);
    });

    document.getElementById('use-saved-address-3').addEventListener('click', function () {
        loadAndPopulateSavedAddress(2);
    });
   
    const savedAddresses = [
        {
            FName: "Nightmare",
            LName: "On",
            Street_Address: "123 Elm St",
            City: "Springfield",
            Country: "USA"
        },
        {
            FName: "Freddy",
            LName: "Fazbear",
            Street_Address: "87 Pizzeria St",
            City: "The Hidden Side",
            Country: "USA"
        },
        {
            FName: "John",
            LName: "Doe",
            Street_Address: "321 Doe St",
            City: "JohnLands",
            Country: "United Johns of Doemerica"
        }
    ];

    localStorage.setItem('addresses', JSON.stringify(savedAddresses));




});

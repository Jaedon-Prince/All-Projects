document.addEventListener("DOMContentLoaded", function () {
    let userAccounts = [
        { username: "Gooba", password: "senzawa" },
        { username: "Calliope", password: "shinigami" }
    ];

    function loginUser() {
        const enteredUsername = document.querySelector("#username").value;
        const enteredPassword = document.querySelector("#Password").value;

        const accountExists = userAccounts.some(account => account.username === enteredUsername && account.password === enteredPassword);

        if (accountExists) {
            alert(`Login successful! Welcome, ${enteredUsername}. Redirecting to Order Page...`);
            window.location.href = "Order_Page.html";
        } else {
            alert("Incorrect username or password. Please try again.");
        }
    }

function registerUser() {
    const firstName = document.getElementById("FName").value;
    const lastName = document.getElementById("LName").value;
    const email = document.getElementById("email").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("Password").value;
    const birthDate = document.getElementById("DOB").value;

    if (!firstName || !lastName || !email || !username || !password || !birthDate) {
        alert("Please fill out all required fields.");
        return;
    }

    const isUsernameTaken = userAccounts.some((user) => user.username === username);

    if (isUsernameTaken) {
        alert("Username already taken. Please choose another.");
    } else {
        userAccounts.push({ username, password });

        document.getElementById("FName").value = "";
        document.getElementById("LName").value = "";
        document.getElementById("email").value = "";
        document.getElementById("username").value = "";
        document.getElementById("Password").value = "";
        document.getElementById("DOB").value = "";

        alert("Registration successful! You can now login with your new account and will be redirected to the Order Page.");

        localStorage.setItem("userAccounts", JSON.stringify(userAccounts));

        window.location.href = "Order_Page.html";
    }
}

const loginButton = document.getElementById("Login-button");
if (loginButton) {
    loginButton.addEventListener("click", loginUser);
}

    const registerButton = document.getElementById("Register-button");
    if (registerButton) {
        registerButton.addEventListener("click", registerUser);
    }

    const storedUserAccounts = localStorage.getItem("userAccounts");
    if (storedUserAccounts) {
        userAccounts = JSON.parse(storedUserAccounts);
    }
});
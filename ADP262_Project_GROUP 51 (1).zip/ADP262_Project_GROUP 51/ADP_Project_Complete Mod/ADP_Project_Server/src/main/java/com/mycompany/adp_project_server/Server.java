package com.mycompany.adp_project_server;

import za.ac.cput.DomainClass;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.List;

public class Server {

    private ServerSocket listener;
    private Socket client;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ServerGui gui;
    private CreationDAO vehicleDAO;

    public Server(ServerGui gui) {
        this.gui = gui;
        this.vehicleDAO = new CreationDAO(); // Initialize DAO to interact with the DB
    }

    public void start() {
        try {
            listener = new ServerSocket(6666);
            gui.updateClientTextArea("Server started. Waiting for clients...");
            listenForClients(); // Start listening for clients
        } catch (IOException e) {
            gui.updateClientTextArea("Error starting server: " + e.getMessage());
        }
    }

    private void listenForClients() throws IOException {
        try {
            client = listener.accept(); // Accept a client connection
            gui.updateClientTextArea("Client connected.");
            getStreams(); // Setup streams for communication
            processClient(); // Process client nonsense/requests
        } catch (IOException e) {
            gui.updateClientTextArea("Error accepting client: " + e.getMessage());
        }
    }

    private void getStreams() throws IOException {
        try {
            out = new ObjectOutputStream(client.getOutputStream());
            out.flush(); // Ensure the output stream is flushed(keep things fresh)
            in = new ObjectInputStream(client.getInputStream());
            gui.updateClientTextArea("Communication streams set up.");
        } catch (IOException e) {
            gui.updateClientTextArea("Error setting up communication streams: " + e.getMessage());
        }
    }

    private void sendData(Object data) {
        try {
            out.writeObject(data);
            out.flush(); // Ensure the data is flushed(fresh again)
            gui.updateClientTextArea("Data sent to client: " + data.toString());
        } catch (IOException e) {
            gui.updateClientTextArea("Error sending data: " + e.getMessage());
        }
    }

    public void closeConnection() {   //all the ways the connection can be closed in case of faulty requests
        try {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
            if (client != null) {
                client.close();
            }
            if (listener != null) {
                listener.close();
            }
            gui.updateClientTextArea("Connection closed.");
        } catch (IOException e) {
            gui.updateClientTextArea("Error closing connection: " + e.getMessage());
        }
    }

    public void processClient() {
        try {
            do {
                Object receivedData = in.readObject(); // Read the incoming data

                if (receivedData instanceof String) {
                    String data = (String) receivedData;

                    // Handle the "Request Updated Data" action //Made it shorter 
                    if (data.equalsIgnoreCase("Request")) {
                        List<DomainClass> vehicles = vehicleDAO.getAllVehicles();
                        sendData(vehicles);
                        gui.updateClientTextArea("Sending updated vehicle data to client.");
                        // Send vehicle list back to the client

                        // Handle adding a new vehicle by name
                    } else if (!isExistingVehicle(data)) {
                        String vehicleId = generateUniqueVehicleId(); // Generate a unique ID for the vehicle
                        DomainClass newVehicle = new DomainClass(vehicleId, data, 0); // New vehicle with 0 votes

                        try {
                            vehicleDAO.insertVehicle(newVehicle);
                            gui.updateClientTextArea("New vehicle added: " + data + " (ID: " + vehicleId + ")");
                        } catch (SQLException e) {
                            gui.updateClientTextArea("Error adding vehicle: " + e.getMessage());
                        }

                        // Handle voting for a vehicle by name
                    } else if (isExistingVehicle(data)) {
                        try {
                            String vehicleId = getVehicleIdByName(data); // Get vehicle ID by its name
                            vehicleDAO.incrementVoteCount(vehicleId); // Increment vote count
                            gui.updateClientTextArea("Vote cast for: " + data);
                            
                        } catch (SQLException e) {
                            gui.updateClientTextArea("Error casting vote: " + e.getMessage());
                        }

                    } else {
                        gui.updateClientTextArea("Unrecognized input: " + data);
                    }
                }

            } while (true);
        } catch (IOException | ClassNotFoundException | SQLException e) {
            gui.updateClientTextArea("Error during communication: " + e.getMessage());
        }
    }

// Helper method to check if the data/vehicle name is in the database, if it is in the database then a vote is cast for it.
    private boolean isExistingVehicle(String data) throws SQLException {
        return vehicleDAO.vehicleExists(data); // Check if the vehicle exists in the database
    }

// Helper method to generate a unique vehicle ID
    private String generateUniqueVehicleId() {
        try {

            String latestVehicleId = vehicleDAO.getLatestVehicleId();
            if (latestVehicleId != null && latestVehicleId.startsWith("HC")) {
                // Get the numerical part after "HC"
                String numericPart = latestVehicleId.substring(2);
                int idNumber = Integer.parseInt(numericPart);
                idNumber++;  // Increment the number for the new ID
                return "HC" + idNumber;  // Return ID back as complete value with "HC"
            } else {
                //If there are no other IDs then start with HC1
                return "HC1";
            }
        } catch (SQLException e) {
            gui.updateClientTextArea("Error generating unique vehicle ID: " + e.getMessage());
            // If there's an error, return a fallback vehicle ID
            return "HC" + (int) (Math.random() * 1000); 
        }
    }

// Helper method to get vehicle ID by name
    private String getVehicleIdByName(String vehicleName) throws SQLException {
        return vehicleDAO.getVehicleIdByName(vehicleName);
    }
}

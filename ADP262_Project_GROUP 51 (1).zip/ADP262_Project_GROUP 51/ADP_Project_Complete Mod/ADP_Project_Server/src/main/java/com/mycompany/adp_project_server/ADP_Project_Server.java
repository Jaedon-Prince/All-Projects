package com.mycompany.adp_project_server;

import java.sql.SQLException;
import za.ac.cput.DomainClass;

public class ADP_Project_Server {

    public static void main(String[] args) {
        CreationDAO subjectDAO = new CreationDAO();
        try {
            // Create table and inserts sample data if they dont exist already
            subjectDAO.createTable();
            System.out.println("Table Checked/Created Successfully....");

            DomainClass[] vehicles = {
                new DomainClass("HC1", "Ford Ranger", 7),
                new DomainClass("HC2", "Audi A3", 10),
                new DomainClass("HC3", "BMW X3", 15),
                new DomainClass("HC4", "Toyota Starlet", 20),
                new DomainClass("HC5", "Suzuki Swift", 5)
            };

            for (DomainClass vehicle : vehicles) {
                subjectDAO.insertVehicle(vehicle);
                System.out.println("Inserted vehicle: " + vehicle.getVehicle_name());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
            return;
        }

        // Makes sure the GUI only starts after everything in the database runs
        new com.mycompany.adp_project_server.ServerGui();

    }
}

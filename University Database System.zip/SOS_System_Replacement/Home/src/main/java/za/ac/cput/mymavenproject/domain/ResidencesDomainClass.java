package za.ac.cput.mymavenproject.domain;

public class ResidencesDomainClass {
    private String resID;
    private String resName;
    private String campusID;
    private String dblRoomCost;
    private String totDblRooms;
    private String availDblRooms;
    private String snglRoomCost;
    private String totSnglRooms;
    private String availSnglRooms;

    public ResidencesDomainClass(String resID, String resName, String campusID, String dblRoomCost, String totDblRooms, String availDblRooms, String snglRoomCost, String totSnglRooms, String availSnglRooms) {
        this.resID = resID;
        this.resName = resName;
        this.campusID = campusID;
        this.dblRoomCost = dblRoomCost;
        this.totDblRooms = totDblRooms;
        this.availDblRooms = availDblRooms;
        this.snglRoomCost = snglRoomCost;
        this.totSnglRooms = totSnglRooms;
        this.availSnglRooms = availSnglRooms;
    }

    public ResidencesDomainClass() {}

    // Getters and Setters
    public String getResID() { return resID; }
    public void setResID(String resID) { this.resID = resID; }
    public String getResName() { return resName; }
    public void setResName(String resName) { this.resName = resName; }
    public String getCampusID() { return campusID; }
    public void setCampusID(String campusID) { this.campusID = campusID; }
    public String getDblRoomCost() { return dblRoomCost; }
    public void setDblRoomCost(String dblRoomCost) { this.dblRoomCost = dblRoomCost; }
    public String getTotDblRooms() { return totDblRooms; }
    public void setTotDblRooms(String totDblRooms) { this.totDblRooms = totDblRooms; }
    public String getAvailDblRooms() { return availDblRooms; }
    public void setAvailDblRooms(String availDblRooms) { this.availDblRooms = availDblRooms; }
    public String getSnglRoomCost() { return snglRoomCost; }
    public void setSnglRoomCost(String snglRoomCost) { this.snglRoomCost = snglRoomCost; }
    public String getTotSnglRooms() { return totSnglRooms; }
    public void setTotSnglRooms(String totSnglRooms) { this.totSnglRooms = totSnglRooms; }
    public String getAvailSnglRooms() { return availSnglRooms; }
    public void setAvailSnglRooms(String availSnglRooms) { this.availSnglRooms = availSnglRooms; }

    // Populate the previously unused methods
    public String getDBLRoomCost() {
        return dblRoomCost; // Return the double room cost
    }

    public String getTOTDBLRooms() {
        return totDblRooms; // Return the total double rooms
    }

    public String getAvailDBLRooms() {
        return availDblRooms; // Return the available double rooms
    }

    public String getSNGLRoomCost() {
        return snglRoomCost; // Return the single room cost
    }

    public String getTOTSNGLRooms() {
        return totSnglRooms; // Return the total single rooms
    }

    public String getAvailSNGLRooms() {
        return availSnglRooms; // Return the available single rooms
    }
    public String[] toArray() {
    return new String[]{resID,  resName,  campusID,  dblRoomCost,  totDblRooms,  availDblRooms,  snglRoomCost, totSnglRooms, availSnglRooms};
}
}

package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class ClassesDomainClass {
    private String subjectCodes;
    private String subjectCode;
    private String staffNumber;
    private String classVenue;
    private String timeOfClass;

    public ClassesDomainClass(String subjectCodes, String subjectCode, String staffNumber, String classVenue, String timeOfClass) {
        this.subjectCodes = subjectCodes;
        this.subjectCode = subjectCode;
        this.staffNumber = staffNumber;
        this.classVenue = classVenue;
        this.timeOfClass = timeOfClass;
    }

    public ClassesDomainClass() {}

    public String getSubjectCodes() {
        return subjectCodes;
    }

    public void setSubjectCodes(String subjectCodes) {
        this.subjectCodes = subjectCodes;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getStaffNumber() {
        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {
        this.staffNumber = staffNumber;
    }

    public String getClassVenue() {
        return classVenue;
    }

    public void setClassVenue(String classVenue) {
        this.classVenue = classVenue;
    }

    public String getTimeOfClass() {
        return timeOfClass;
    }

    public void setTimeOfClass(String timeOfClass) {
        this.timeOfClass = timeOfClass;
    }
    public String[] toArray() {
    return new String[]{subjectCodes, subjectCode,  staffNumber,  classVenue, timeOfClass};
}
}

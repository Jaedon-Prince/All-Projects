package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class CampusDomainClass {
    private String campID;
    private String location;
    private String streetName;
    private String facilities;
    private String established;

    public CampusDomainClass(String campID, String location, String streetName, String facilities, String established) {
        this.campID = campID;
        this.location = location;
        this.streetName = streetName;
        this.facilities = facilities;
        this.established = established;
    }

    public CampusDomainClass() {}

    public String getCampID() {
        return campID;
    }

    public void setCampID(String campID) {
        this.campID = campID;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getEstablished() {
        return established;
    }

    public void setEstablished(String established) {
        this.established = established;
    }
    public String[] toArray() {
    return new String[]{campID, location, streetName, facilities, established};
}
}

package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class SubjectDomainClass {
    private String subjectCode;
    private String subject;
    private String duration;
    private String credits;
    private String amount;

    public SubjectDomainClass(String subjectCode, String subject, String duration, String credits, String amount) {
        this.subjectCode = subjectCode;
        this.subject = subject;
        this.duration = duration;
        this.credits = credits;
        this.amount = amount;
    }

    public SubjectDomainClass() {}

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getCredits() {
        return credits;
    }

    public void setCredits(String credits) {
        this.credits = credits;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
    
    
        public String[] toArray() {
        return new String[]{subjectCode, subject, duration, credits,  amount};
    }
}

package za.ac.cput.mymavenproject.dao;

import za.ac.cput.mymavenproject.connection.DBConnection;
import za.ac.cput.mymavenproject.domain.DomainClass;
import za.ac.cput.mymavenproject.domain.LecturerDomainClass;
import za.ac.cput.mymavenproject.domain.CampusDomainClass;
import za.ac.cput.mymavenproject.domain.ClassesDomainClass;
import za.ac.cput.mymavenproject.domain.DiplomaDomainClass;
import za.ac.cput.mymavenproject.domain.StudentMarksDomainClass;
import za.ac.cput.mymavenproject.domain.SubjectDomainClass;
import za.ac.cput.mymavenproject.domain.ResidencesDomainClass;
import za.ac.cput.mymavenproject.domain.PaymentsDomainClass;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CreationDAO {

    public void createTable() throws SQLException {
        String createStudentStmt = "CREATE TABLE Student (Student_Num INTEGER PRIMARY KEY, First_Name VARCHAR(30), ID_Number VARCHAR(30), Street VARCHAR(30), Suburb VARCHAR(30), City VARCHAR(30), Postal_Code INTEGER, Cell_Num VARCHAR(30), Email_Address VARCHAR(30), Dip_Code VARCHAR(30), Res_ID VARCHAR(30), Room_Type VARCHAR(30), Campus_ID VARCHAR(30), Balance VARCHAR(30))";
        String createStudentMarksStmt = "CREATE TABLE StudentMarks (Sub_Code VARCHAR(30) PRIMARY KEY, Student_Num VARCHAR(30), Term1 VARCHAR(30), Term2 VARCHAR(30), Term3 VARCHAR(30), Term4 VARCHAR(30))";
        String createSubjectStmt = "CREATE TABLE Subject (Subject_Code VARCHAR(30) PRIMARY KEY, Subject VARCHAR(30), Duration VARCHAR(30), Credits VARCHAR(30), Amount VARCHAR(30))";
        String createLecturersStmt = "CREATE TABLE Lecturers (Staff_Number VARCHAR(30) PRIMARY KEY, Title VARCHAR(30), Staff_Surname VARCHAR(30), Staff_Name VARCHAR(30), Email VARCHAR(30), Department VARCHAR(30), Diploma_Code VARCHAR(30), Campus VARCHAR(30), Subject_Codes VARCHAR(30))";
        String createClassesStmt = "CREATE TABLE Classes (Subject_Codes VARCHAR(30) PRIMARY KEY, Staff_Number VARCHAR(30), Class_Venue VARCHAR(30), Time_of_Class VARCHAR(30))";
        String createResidencesStmt = "CREATE TABLE Residences (Res_ID VARCHAR(30) PRIMARY KEY, Res_Name VARCHAR(30), Campus_ID VARCHAR(30), DBLRoom_Cost VARCHAR(30), TOT_DBLRooms VARCHAR(30), Avail_DBLRooms VARCHAR(30), SNGLRoom_Cost VARCHAR(30), TOT_SNGLRooms VARCHAR(30), Avail_SNGLRooms VARCHAR(30))";
        String createPaymentsStmt = "CREATE TABLE Payments (Student_Num VARCHAR(30) PRIMARY KEY, Last_Payment VARCHAR(30), Payment_Type VARCHAR(30), Payment_Amount VARCHAR(30))";
        String createDiplomaStmt = "CREATE TABLE Diploma (DipCode VARCHAR(30) PRIMARY KEY, CampID VARCHAR(30), CourseOffering VARCHAR(30), Faculty VARCHAR(30))";
        String createCampusStmt = "CREATE TABLE Campus (CampID VARCHAR(30) PRIMARY KEY, Location VARCHAR(30), Street_Name VARCHAR(30), Facilities VARCHAR(30), Established VARCHAR(30))";

        try (Connection con = DBConnection.getConnection()) {
            DatabaseMetaData dbm = con.getMetaData();

            try (ResultSet rs = dbm.getTables(null, null, "Student", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createStudentStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "StudentMarks", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createStudentMarksStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Subject", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createSubjectStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Lecturers", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createLecturersStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Classes", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createClassesStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Residences", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createResidencesStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Payments", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createPaymentsStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Diploma", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createDiplomaStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
            try (ResultSet rs = dbm.getTables(null, null, "Campus", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createCampusStmt)) {
                        ps.executeUpdate();
                    }
                }
            }
        }
    }
    
    //display statements
    // Method to retrieve all students from the database
    public List<DomainClass> getAllStudents() throws SQLException {
        List<DomainClass> studentList = new ArrayList<>();
        String selectStmt = "SELECT * FROM Student";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(selectStmt);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DomainClass student = new DomainClass();
                student.setStudent_Num(rs.getInt("Student_Num"));
                student.setFirst_Name(rs.getString("First_Name"));
                student.setID_Number(rs.getString("ID_Number"));
                student.setStreet(rs.getString("Street"));
                student.setSuburb(rs.getString("Suburb"));
                student.setCity(rs.getString("City"));
                student.setPostal_Code(rs.getInt("Postal_Code"));
                student.setCell_Num(rs.getString("Cell_Num"));
                student.setEmail_Address(rs.getString("Email_Address"));
                student.setDip_Code(rs.getString("Dip_Code"));
                student.setRes_ID(rs.getString("Res_ID"));
                student.setRoom_Type(rs.getString("Room_Type"));
                student.setCampus_ID(rs.getString("Campus_ID"));
                student.setBalance(rs.getString("Balance"));

                // Add the student object to the list
                studentList.add(student);
            }
        }
        return studentList;  // Returning the list of students
    }

    public List<LecturerDomainClass> getAllLecturers() throws SQLException {
    List<LecturerDomainClass> lecturerList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Lecturers";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            LecturerDomainClass lecturer = new LecturerDomainClass();
            lecturer.setStaffNumber(rs.getString("Staff_Number"));
            lecturer.setTitle(rs.getString("Title"));
            lecturer.setSurname(rs.getString("Staff_Surname"));
            lecturer.setFirstName(rs.getString("Staff_Name"));
            lecturer.setEmail(rs.getString("Email"));
            lecturer.setDepartment(rs.getString("Department"));
            lecturer.setDiploma_Code(rs.getString("Diploma_Code"));
            lecturer.setCampus(rs.getString("Campus"));
            lecturer.setSubjectCode(rs.getString("Subject_Codes"));
            
            lecturerList.add(lecturer);
        }
    }
    return lecturerList;
}
    
public List<StudentMarksDomainClass> getAllStudentMarks() throws SQLException {
    List<StudentMarksDomainClass> studentMarksList = new ArrayList<>();
    String selectStmt = "SELECT * FROM StudentMarks";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            StudentMarksDomainClass studentMarks = new StudentMarksDomainClass();
            studentMarks.setSubCode(rs.getString("Sub_Code"));
            studentMarks.setStudentNum(rs.getString("Student_Num"));
            studentMarks.setTerm1(rs.getString("Term1"));
            studentMarks.setTerm2(rs.getString("Term2"));
            studentMarks.setTerm3(rs.getString("Term3"));
            studentMarks.setTerm4(rs.getString("Term4"));
            
            studentMarksList.add(studentMarks);
        }
    }
    return studentMarksList;
}

public List<SubjectDomainClass> getAllSubjects() throws SQLException {
    List<SubjectDomainClass> subjectList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Subject";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            SubjectDomainClass subject = new SubjectDomainClass();
            subject.setSubjectCode(rs.getString("Subject_Code"));
            subject.setSubject(rs.getString("Subject"));
            subject.setDuration(rs.getString("Duration"));
            subject.setCredits(rs.getString("Credits"));
            subject.setAmount(rs.getString("Amount"));
            
            subjectList.add(subject);
        }
    }
    return subjectList;
}
public List<ClassesDomainClass> getAllClasses() throws SQLException {
    List<ClassesDomainClass> classesList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Classes";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            ClassesDomainClass classes = new ClassesDomainClass();
            classes.setSubjectCode(rs.getString("Subject_Codes"));
            classes.setStaffNumber(rs.getString("Staff_Number"));
            classes.setClassVenue(rs.getString("Class_Venue"));
            classes.setTimeOfClass(rs.getString("Time_of_Class"));
            
            classesList.add(classes);
        }
    }
    return classesList;
}
public List<ResidencesDomainClass> getAllResidences() throws SQLException {
    List<ResidencesDomainClass> residenceList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Residences";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            ResidencesDomainClass residence = new ResidencesDomainClass();
            residence.setResID(rs.getString("Res_ID"));
            residence.setResName(rs.getString("Res_Name"));
            residence.setCampusID(rs.getString("Campus_ID"));
            residence.setDblRoomCost(rs.getString("DBLRoom_Cost"));
            residence.setTotDblRooms(rs.getString("TOT_DBLRooms"));
            residence.setAvailDblRooms(rs.getString("Avail_DBLRooms"));
            residence.setSnglRoomCost(rs.getString("SNGLRoom_Cost"));
            residence.setTotSnglRooms(rs.getString("TOT_SNGLRooms"));
            residence.setAvailSnglRooms(rs.getString("Avail_SNGLRooms"));
            
            residenceList.add(residence);
        }
    }
    return residenceList;
}
public List<PaymentsDomainClass> getAllPayments() throws SQLException {
    List<PaymentsDomainClass> paymentList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Payments";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            PaymentsDomainClass payment = new PaymentsDomainClass();
            payment.setStudentNum(rs.getString("Student_Num"));
            payment.setLastPayment(rs.getString("Last_Payment"));
            payment.setPaymentType(rs.getString("Payment_Type"));
            payment.setPaymentAmount(rs.getString("Payment_Amount"));
            
            paymentList.add(payment);
        }
    }
    return paymentList;
}
public List<DiplomaDomainClass> getAllDiplomas() throws SQLException {
    List<DiplomaDomainClass> diplomaList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Diploma";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            DiplomaDomainClass diploma = new DiplomaDomainClass();
            diploma.setDipCode(rs.getString("DipCode"));
            diploma.setCampID(rs.getString("CampID"));
            diploma.setCourseOffering(rs.getString("CourseOffering"));
            diploma.setFaculty(rs.getString("Faculty"));
            
            diplomaList.add(diploma);
        }
    }
    return diplomaList;
}
public List<CampusDomainClass> getAllCampuses() throws SQLException {
    List<CampusDomainClass> campusList = new ArrayList<>();
    String selectStmt = "SELECT * FROM Campus";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(selectStmt);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            CampusDomainClass campus = new CampusDomainClass();
            campus.setCampID(rs.getString("CampID"));
            campus.setLocation(rs.getString("Location"));
            campus.setStreetName(rs.getString("Street_Name"));
            campus.setFacilities(rs.getString("Facilities"));
            campus.setEstablished(rs.getString("Established"));
            
            campusList.add(campus);
        }
    }
    return campusList;
}

   
    
    //insert statements
    public void insertStudent(DomainClass domain) throws SQLException {
        String insertStmt = "INSERT INTO Student (Student_Num, First_Name, ID_Number, Street, Suburb, City, Postal_Code, Cell_Num, Email_Address, Dip_Code, Res_ID, Room_Type, Campus_ID, Balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setInt(1, domain.getStudent_Num());
            ps.setString(2, domain.getFirst_Name());
            ps.setString(3, domain.getID_Number());
            ps.setString(4, domain.getStreet());
            ps.setString(5, domain.getSuburb());
            ps.setString(6, domain.getCity());
            ps.setInt(7, domain.getPostal_Code());
            ps.setString(8, domain.getCell_Num());
            ps.setString(9, domain.getEmail_Address());
            ps.setString(10, domain.getDip_Code());
            ps.setString(11, domain.getRes_ID());
            ps.setString(12, domain.getRoom_Type());
            ps.setString(13, domain.getCampus_ID());
            ps.setString(14, domain.getBalance());
            ps.executeUpdate();
        }
    }

    public void insertLecturer(LecturerDomainClass lecturer) throws SQLException {
        String insertStmt = "INSERT INTO Lecturers (Staff_Number, Title, Staff_Surname, Staff_Name, Email, Department, Diploma_Code, Campus, Subject_Codes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, lecturer.getStaffNumber());
            ps.setString(2, lecturer.getTitle());
            ps.setString(3, lecturer.getSurname());
            ps.setString(4, lecturer.getFirstName());
            ps.setString(5, lecturer.getEmail());
            ps.setString(6, lecturer.getDepartment());
            ps.setString(7, lecturer.getDiploma_Code());
            ps.setString(8, lecturer.getCampus());
            ps.setString(9, lecturer.getSubjectCode());
            ps.executeUpdate();
        }
    }

    public void insertStudentMarks(StudentMarksDomainClass studentMarks) throws SQLException {
        String insertStmt = "INSERT INTO StudentMarks (Sub_Code, Student_Num, Term1, Term2, Term3, Term4) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, studentMarks.getSubCode());
            ps.setString(2, studentMarks.getStudentNum());
            ps.setString(3, studentMarks.getTerm1());
            ps.setString(4, studentMarks.getTerm2());
            ps.setString(5, studentMarks.getTerm3());
            ps.setString(6, studentMarks.getTerm4());
            ps.executeUpdate();
        }
    }

    public void insertSubject(SubjectDomainClass subject) throws SQLException {
        String insertStmt = "INSERT INTO Subject (Subject_Code, Subject, Duration, Credits, Amount) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, subject.getSubjectCode());
            ps.setString(2, subject.getSubject());
            ps.setString(3, subject.getDuration());
            ps.setString(4, subject.getCredits());
            ps.setString(5, subject.getAmount());
            ps.executeUpdate();
        }
    }

    public void insertClasses(ClassesDomainClass classes) throws SQLException {
        String insertStmt = "INSERT INTO Classes (Subject_Codes, Staff_Number, Class_Venue, Time_of_Class) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, classes.getSubjectCode());
            ps.setString(2, classes.getStaffNumber());
            ps.setString(3, classes.getClassVenue());
            ps.setString(4, classes.getTimeOfClass());
            ps.executeUpdate();
        }
    }

    public void insertResidences(ResidencesDomainClass residences) throws SQLException {
        String insertStmt = "INSERT INTO Residences (Res_ID, Res_Name, Campus_ID, DBLRoom_Cost, TOT_DBLRooms, Avail_DBLRooms, SNGLRoom_Cost, TOT_SNGLRooms, Avail_SNGLRooms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, residences.getResID());
            ps.setString(2, residences.getResName());
            ps.setString(3, residences.getCampusID());
            ps.setString(4, residences.getDBLRoomCost());
            ps.setString(5, residences.getTOTDBLRooms());
            ps.setString(6, residences.getAvailDBLRooms());
            ps.setString(7, residences.getSNGLRoomCost());
            ps.setString(8, residences.getTOTSNGLRooms());
            ps.setString(9, residences.getAvailSNGLRooms());
            ps.executeUpdate();
        }
    }

    public void insertPayments(PaymentsDomainClass payments) throws SQLException {
        String insertStmt = "INSERT INTO Payments (Student_Num, Last_Payment, Payment_Type, Payment_Amount) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, payments.getStudentNum());
            ps.setString(2, payments.getLastPayment());
            ps.setString(3, payments.getPaymentType());
            ps.setString(4, payments.getPaymentAmount());
            ps.executeUpdate();
        }
    }

    public void insertDiploma(DiplomaDomainClass diploma) throws SQLException {
        String insertStmt = "INSERT INTO Diploma (DipCode, CampID, CourseOffering, Faculty) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, diploma.getDipCode());
            ps.setString(2, diploma.getCampID());
            ps.setString(3, diploma.getCourseOffering());
            ps.setString(4, diploma.getFaculty());
            ps.executeUpdate();
        }
    }

    public void insertCampus(CampusDomainClass campus) throws SQLException {
        String insertStmt = "INSERT INTO Campus (CampID, Location, Street_Name, Facilities, Established) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, campus.getCampID());
            ps.setString(2, campus.getLocation());
            ps.setString(3, campus.getStreetName());
            ps.setString(4, campus.getFacilities());
            ps.setString(5, campus.getEstablished());
            ps.executeUpdate();
        }
    }

    public void insertClass(ClassesDomainClass classesDomainClass) throws SQLException {
        String insertStmt = "INSERT INTO Classes (Subject_Codes, Staff_Number, Class_Venue, Time_of_Class) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, classesDomainClass.getSubjectCode());
            ps.setString(2, classesDomainClass.getStaffNumber());
            ps.setString(3, classesDomainClass.getClassVenue());
            ps.setString(4, classesDomainClass.getTimeOfClass());
            ps.executeUpdate();
        }
    }
    // ------------------ Update Methods ------------------

    public void updateStudent(DomainClass domain, int studentNum) throws SQLException {
        String updateStmt = "UPDATE Student SET First_Name = ?, ID_Number = ?, Street = ?, Suburb = ?, City = ?, Postal_Code = ?, Cell_Num = ?, Email_Address = ?, Dip_Code = ?, Res_ID = ?, Room_Type = ?, Campus_ID = ?, Balance = ? WHERE Student_Num = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, domain.getFirst_Name());
            ps.setString(2, domain.getID_Number());
            ps.setString(3, domain.getStreet());
            ps.setString(4, domain.getSuburb());
            ps.setString(5, domain.getCity());
            ps.setInt(6, domain.getPostal_Code());
            ps.setString(7, domain.getCell_Num());
            ps.setString(8, domain.getEmail_Address());
            ps.setString(9, domain.getDip_Code());
            ps.setString(10, domain.getRes_ID());
            ps.setString(11, domain.getRoom_Type());
            ps.setString(12, domain.getCampus_ID());
            ps.setString(13, domain.getBalance());
            ps.setInt(14, studentNum);
            ps.executeUpdate();
        }
    }

    public void updateLecturer(LecturerDomainClass lecturer, String oldEmail) throws SQLException {
        String updateStmt = "UPDATE Lecturers SET Title = ?, Staff_Surname = ?, Staff_Name = ?, Email = ?, Department = ?, Diploma_Code = ?, Campus = ?, Subject_Codes = ? WHERE Email = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, lecturer.getTitle());
            ps.setString(2, lecturer.getSurname());
            ps.setString(3, lecturer.getFirstName());
            ps.setString(4, lecturer.getEmail());
            ps.setString(5, lecturer.getDepartment());
            ps.setString(6, lecturer.getDiploma_Code());
            ps.setString(7, lecturer.getCampus());
            ps.setString(8, lecturer.getSubjectCode());
            ps.setString(9, oldEmail);
            ps.executeUpdate();
        }
    }

    public void updateStudentMarks(StudentMarksDomainClass studentMarks, String subCode) throws SQLException {
        String updateStmt = "UPDATE StudentMarks SET Term1 = ?, Term2 = ?, Term3 = ?, Term4 = ? WHERE Sub_Code = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, studentMarks.getTerm1());
            ps.setString(2, studentMarks.getTerm2());
            ps.setString(3, studentMarks.getTerm3());
            ps.setString(4, studentMarks.getTerm4());
            ps.setString(5, subCode);
            ps.executeUpdate();
        }
    }

    public void updateSubject(SubjectDomainClass subject, String subjectCode) throws SQLException {
        String updateStmt = "UPDATE Subject SET Subject = ?, Duration = ?, Credits = ?, Amount = ? WHERE Subject_Code = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, subject.getSubject());
            ps.setString(2, subject.getDuration());
            ps.setString(3, subject.getCredits());
            ps.setString(4, subject.getAmount());
            ps.setString(5, subjectCode);
            ps.executeUpdate();
        }
    }

    public void updateClasses(ClassesDomainClass classes, String subjectCode) throws SQLException {
        String updateStmt = "UPDATE Classes SET Staff_Number = ?, Class_Venue = ?, Time_of_Class = ? WHERE Subject_Codes = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, classes.getStaffNumber());
            ps.setString(2, classes.getClassVenue());
            ps.setString(3, classes.getTimeOfClass());
            ps.setString(4, subjectCode);
            ps.executeUpdate();
        }
    }

    public void updateResidences(ResidencesDomainClass residences, String resID) throws SQLException {
        String updateStmt = "UPDATE Residences SET Res_Name = ?, Campus_ID = ?, DBLRoom_Cost = ?, TOT_DBLRooms = ?, Avail_DBLRooms = ?, SNGLRoom_Cost = ?, TOT_SNGLRooms = ?, Avail_SNGLRooms = ? WHERE Res_ID = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, residences.getResName());
            ps.setString(2, residences.getCampusID());
            ps.setString(3, residences.getDBLRoomCost());
            ps.setString(4, residences.getTOTDBLRooms());
            ps.setString(5, residences.getAvailDBLRooms());
            ps.setString(6, residences.getSNGLRoomCost());
            ps.setString(7, residences.getTOTSNGLRooms());
            ps.setString(8, residences.getAvailSNGLRooms());
            ps.setString(9, resID);
            ps.executeUpdate();
        }
    }

    public void updatePayments(PaymentsDomainClass payments, String studentNum) throws SQLException {
        String updateStmt = "UPDATE Payments SET Last_Payment = ?, Payment_Type = ?, Payment_Amount = ? WHERE Student_Num = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, payments.getLastPayment());
            ps.setString(2, payments.getPaymentType());
            ps.setString(3, payments.getPaymentAmount());
            ps.setString(4, studentNum);
            ps.executeUpdate();
        }
    }

    public void updateDiploma(DiplomaDomainClass diploma, String dipCode) throws SQLException {
        String updateStmt = "UPDATE Diploma SET CampID = ?, CourseOffering = ?, Faculty = ? WHERE DipCode = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, diploma.getCampID());
            ps.setString(2, diploma.getCourseOffering());
            ps.setString(3, diploma.getFaculty());
            ps.setString(4, dipCode);
            ps.executeUpdate();
        }
    }

    public void updateCampus(CampusDomainClass campus, String campID) throws SQLException {
        String updateStmt = "UPDATE Campus SET Location = ?, Street_Name = ?, Facilities = ?, Established = ? WHERE CampID = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, campus.getLocation());
            ps.setString(2, campus.getStreetName());
            ps.setString(3, campus.getFacilities());
            ps.setString(4, campus.getEstablished());
            ps.setString(5, campID);
            ps.executeUpdate();
        }
    }

// ------------------ Delete Methods ------------------
    public static void deleteStudent(int studentNum) throws SQLException {
        String deleteStmt = "DELETE FROM Student WHERE Student_Num = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setInt(1, studentNum);
            ps.executeUpdate();
        }
    }

    public static void deleteLecturer(String email) throws SQLException {
        String deleteStmt = "DELETE FROM Lecturers WHERE Email = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, email);
            ps.executeUpdate();
        }
    }

    public static void deleteStudentMarks(String subCode) throws SQLException {
        String deleteStmt = "DELETE FROM StudentMarks WHERE Sub_Code = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, subCode);
            ps.executeUpdate();
        }
    }

    public static void deleteSubject(String subjectCode) throws SQLException {
        String deleteStmt = "DELETE FROM Subject WHERE Subject_Code = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, subjectCode);
            ps.executeUpdate();
        }
    }

    public static void deleteClasses(String subjectCode) throws SQLException {
        String deleteStmt = "DELETE FROM Classes WHERE Subject_Codes = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, subjectCode);
            ps.executeUpdate();
        }
    }

    public static void deleteResidences(String resID) throws SQLException {
        String deleteStmt = "DELETE FROM Residences WHERE Res_ID = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, resID);
            ps.executeUpdate();
        }
    }

    public static void deletePayments(String studentNum) throws SQLException {
        String deleteStmt = "DELETE FROM Payments WHERE Student_Num = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, studentNum);
            ps.executeUpdate();
        }
    }

    public static void deleteDiploma(String dipCode) throws SQLException {
        String deleteStmt = "DELETE FROM Diploma WHERE DipCode = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, dipCode);
            ps.executeUpdate();
        }
    }

    public static void deleteCampus(String campID) throws SQLException {
        String deleteStmt = "DELETE FROM Campus WHERE CampID = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, campID);
            ps.executeUpdate();
        }
    }

    
    
 //-----------------------------------------Search statements-------------------------------------------------
public static List<DomainClass> searchStudent(String keyword) {
    List<DomainClass> students = new ArrayList<>();
    
    try {
        // Prepare the SQL query
        String query = "SELECT * FROM Student WHERE " +
                "Student_Num = ? OR First_Name LIKE ? OR ID_Number LIKE ? " +
                "OR Street LIKE ? OR Suburb LIKE ? OR City LIKE ? " +
                "OR Postal_Code = ? OR Cell_Num LIKE ? OR Email_Address LIKE ? " +
                "OR Dip_Code LIKE ? OR Res_ID LIKE ? OR Room_Type LIKE ? " +
                "OR Campus_ID LIKE ? OR Balance LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        // Initialize search patterns
        String searchKeyword = "%" + keyword + "%";

        // Try to parse the keyword for integer fields
        Integer studentNum = null;
        Integer postalCode = null;

        try {
            studentNum = Integer.parseInt(keyword); // Parse for Student_Num
        } catch (NumberFormatException e) {
            // Handle the case where parsing fails
            System.out.println("Invalid Student_Num format, will search with LIKE instead.");
        }

        try {
            postalCode = Integer.parseInt(keyword); // Parse for Postal_Code
        } catch (NumberFormatException e) {
            // Handle the case where parsing fails
            System.out.println("Invalid Postal_Code format, will search with LIKE instead.");
        }

        // Set parameters for the prepared statement
        statement.setObject(1, studentNum != null ? studentNum : null); // Student_Num
        statement.setString(2, searchKeyword); // First_Name
        statement.setString(3, searchKeyword); // ID_Number
        statement.setString(4, searchKeyword); // Street
        statement.setString(5, searchKeyword); // Suburb
        statement.setString(6, searchKeyword); // City
        statement.setObject(7, postalCode != null ? postalCode : null); // Postal_Code
        statement.setString(8, searchKeyword); // Cell_Num
        statement.setString(9, searchKeyword); // Email_Address
        statement.setString(10, searchKeyword); // Dip_Code
        statement.setString(11, searchKeyword); // Res_ID
        statement.setString(12, searchKeyword); // Room_Type
        statement.setString(13, searchKeyword); // Campus_ID
        statement.setString(14, searchKeyword); // Balance

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            DomainClass student = new DomainClass(
                    resultSet.getInt("Student_Num"),
                    resultSet.getString("First_Name"),
                    resultSet.getString("ID_Number"),
                    resultSet.getString("Street"),
                    resultSet.getString("Suburb"),
                    resultSet.getString("City"),
                    resultSet.getInt("Postal_Code"),
                    resultSet.getString("Cell_Num"),
                    resultSet.getString("Email_Address"),
                    resultSet.getString("Dip_Code"),
                    resultSet.getString("Res_ID"),
                    resultSet.getString("Room_Type"),
                    resultSet.getString("Campus_ID"),
                    resultSet.getString("Balance")
            );
            students.add(student);
        }
        
        resultSet.close();
        statement.close();
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return students;
}



public static List<StudentMarksDomainClass> searchStudentMarks(String keyword) {
    List<StudentMarksDomainClass> marksList = new ArrayList<>();

    try {
        String query = "SELECT * FROM StudentMarks WHERE " +
                " Sub_Code LIKE ? OR Student_Num = ? OR Term1 LIKE ? " +
                "OR Term2 LIKE ? OR Term3 LIKE ? OR Term4 LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        // Initialize search patterns
        String searchKeyword = "%" + keyword + "%";
        Integer studentNum = null;

        // Try to parse the keyword for integer fields
        try {
            studentNum = Integer.parseInt(keyword);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Student_Num format, will search with LIKE instead.");
        }

        // Set parameters for the prepared statement

        statement.setString(1, searchKeyword); // Sub_Code
        statement.setObject(2, studentNum != null ? studentNum : null); // Student_Num
        statement.setString(3, searchKeyword); // Term1
        statement.setString(4, searchKeyword); // Term2
        statement.setString(5, searchKeyword); // Term3
        statement.setString(6, searchKeyword); // Term4

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            StudentMarksDomainClass marks = new StudentMarksDomainClass(
                    resultSet.getString("Sub_Code"),
                    resultSet.getString("Student_Num"),
                    resultSet.getString("Term1"),
                    resultSet.getString("Term2"),
                    resultSet.getString("Term3"),
                    resultSet.getString("Term4")
            );
            marksList.add(marks);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return marksList;
}
public static List<CampusDomainClass> searchCampus(String keyword) {
    List<CampusDomainClass> campusList = new ArrayList<>();

    try {
        String query = "SELECT * FROM Campus WHERE " +
                "CampID LIKE ? OR Location LIKE ? OR Street_Name LIKE ? " +
                "OR Facilities LIKE ? OR Established LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        String searchKeyword = "%" + keyword + "%";

        // Set parameters for the prepared statement
        for (int i = 1; i <= 5; i++) {
            statement.setString(i, searchKeyword); // All fields searched with LIKE
        }

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            CampusDomainClass campus = new CampusDomainClass(
                    resultSet.getString("CampID"),
                    resultSet.getString("Location"),
                    resultSet.getString("Street_Name"),
                    resultSet.getString("Facilities"),
                    resultSet.getString("Established")
            );
            campusList.add(campus);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return campusList;
}   
public static List<DiplomaDomainClass> searchDiploma(String keyword) {
    List<DiplomaDomainClass> diplomaList = new ArrayList<>();

    try {
        String query = "SELECT * FROM Diploma WHERE " +
                "DipCode LIKE ? OR CampID LIKE ? OR CourseOffering LIKE ? " +
                "OR Faculty LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        String searchKeyword = "%" + keyword + "%";

        // Set parameters for the prepared statement
        for (int i = 1; i <= 4; i++) {
            statement.setString(i, searchKeyword); // All fields searched with LIKE
        }

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            DiplomaDomainClass diploma = new DiplomaDomainClass(
                    resultSet.getString("DipCode"),
                    resultSet.getString("CampID"),
                    resultSet.getString("CourseOffering"),
                    resultSet.getString("Faculty")
            );
            diplomaList.add(diploma);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return diplomaList;
}    
public static List<LecturerDomainClass> searchLecturers(String keyword) {
    List<LecturerDomainClass> lecturerList = new ArrayList<>();

    try {
        String query = "SELECT * FROM Lecturers WHERE " +
                "Staff_Number LIKE ? OR Title LIKE ? OR Staff_Surname LIKE ? OR Staff_Name LIKE ? " +
                "OR Email LIKE ? OR Department LIKE ? " +
                "OR Diploma_Code LIKE ? OR Campus LIKE ? OR Subject_Codes LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        String searchKeyword = "%" + keyword + "%";

        // Set parameters for the prepared statement
        for (int i = 1; i <= 9; i++) {
            statement.setString(i, searchKeyword); // All fields searched with LIKE
        }

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            LecturerDomainClass lecturer = new LecturerDomainClass( 
                    
                    resultSet.getString("Title"),
                    resultSet.getString("Staff_Number"),
                    resultSet.getString("Staff_Surname"),
                    resultSet.getString("Staff_Name"),
                    resultSet.getString("Email"),
                    resultSet.getString("Department"),
                    resultSet.getString("Diploma_Code"),
                    resultSet.getString("Campus"),
                    resultSet.getString("Subject_Codes")
            );
            lecturerList.add(lecturer);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lecturerList;
}   
public static List<ResidencesDomainClass> searchResidences(String keyword) {
    List<ResidencesDomainClass> residencesList = new ArrayList<>();

    try {
        String query = "SELECT * FROM Residences WHERE " +
                "Res_ID LIKE ? OR Res_Name LIKE ? OR Campus_ID LIKE ? " +
                "OR DblRoom_Cost LIKE ? OR Tot_DblRooms LIKE ? " +
                "OR Avail_DblRooms LIKE ? OR SnglRoom_Cost LIKE ? " +
                "OR Tot_SnglRooms LIKE ? OR Avail_SnglRooms LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        String searchKeyword = "%" + keyword + "%";

        // Set parameters for the prepared statement
        for (int i = 1; i <= 9; i++) {
            statement.setString(i, searchKeyword); // All fields searched with LIKE
        }

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            ResidencesDomainClass residence = new ResidencesDomainClass(
                    resultSet.getString("Res_ID"),
                    resultSet.getString("Res_Name"),
                    resultSet.getString("Campus_ID"),
                    resultSet.getString("DblRoom_Cost"),
                    resultSet.getString("Tot_DblRooms"),
                    resultSet.getString("Avail_DblRooms"),
                    resultSet.getString("SnglRoom_Cost"),
                    resultSet.getString("Tot_SnglRooms"),
                    resultSet.getString("Avail_SnglRooms")
            );
            residencesList.add(residence);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return residencesList;
} 
public static List<SubjectDomainClass> searchSubject(String keyword) {
    List<SubjectDomainClass> subjectList = new ArrayList<>();

    try {
        String query = "SELECT * FROM Subject WHERE " +
                "Subject_Code LIKE ? OR Subject LIKE ? OR Duration LIKE ? " +
                "OR Credits LIKE ? OR Amount LIKE ?";

        Connection con = DBConnection.getConnection();
        PreparedStatement statement = con.prepareStatement(query);
        
        String searchKeyword = "%" + keyword + "%";

        // Set parameters for the prepared statement
        for (int i = 1; i <= 5; i++) {
            statement.setString(i, searchKeyword); // All fields searched with LIKE
        }

        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            SubjectDomainClass subject = new SubjectDomainClass(
                    resultSet.getString("Subject_Code"),
                    resultSet.getString("Subject"),
                    resultSet.getString("Duration"),
                    resultSet.getString("Credits"),
                    resultSet.getString("Amount")
            );
            subjectList.add(subject);
        }

        resultSet.close();
        statement.close();

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return subjectList;
}










}

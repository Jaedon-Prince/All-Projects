package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class StudentMarksDomainClass {
    private String subCode;
    private String studentNum;
    private String term1;
    private String term2;
    private String term3;
    private String term4;

    public StudentMarksDomainClass(String subCode, String studentNum, String term1, String term2, String term3, String term4) {
        this.subCode = subCode;
        this.studentNum = studentNum;
        this.term1 = term1;
        this.term2 = term2;
        this.term3 = term3;
        this.term4 = term4;
    }

    public StudentMarksDomainClass() {}

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(String studentNum) {
        this.studentNum = studentNum;
    }

    public String getTerm1() {
        return term1;
    }

    public void setTerm1(String term1) {
        this.term1 = term1;
    }

    public String getTerm2() {
        return term2;
    }

    public void setTerm2(String term2) {
        this.term2 = term2;
    }

    public String getTerm3() {
        return term3;
    }

    public void setTerm3(String term3) {
        this.term3 = term3;
    }

    public String getTerm4() {
        return term4;
    }

    public void setTerm4(String term4) {
        this.term4 = term4;
    }
    public String[] toArray() {
    return new String[]{subCode,studentNum, term1, term2, term3, term4};
}
}

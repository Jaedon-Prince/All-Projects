/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class DomainClass {
 private int Student_Num;
    private String First_Name;
    private String ID_Number;
    private String Street;
    private String Suburb;
    private String City;
    private int Postal_Code;
    private String Cell_Num;
    private String Email_Address;
    private String Dip_Code;
    private String Res_ID;
    private String Room_Type;
    private String Campus_ID;
    private String Balance;


  public DomainClass(int Student_Num, String First_Name, String ID_Number, String Street, String Suburb, String City, int Postal_Code, String Cell_Num, String Email_Address, String Dip_Code, String Res_ID, String Room_Type, String Campus_ID, String Balance) {
    this.Student_Num = Student_Num;
    this.First_Name = First_Name;
    this.ID_Number = ID_Number;
    this.Street = Street;
    this.Suburb = Suburb;
    this.City = City;
    this.Postal_Code = Postal_Code;
    this.Cell_Num = Cell_Num;
    this.Email_Address = Email_Address;
    this.Dip_Code = Dip_Code;
    this.Res_ID = Res_ID;
    this.Room_Type = Room_Type;
    this.Campus_ID = Campus_ID;
    this.Balance = Balance;
}
    public DomainClass() {
    }

    public int getStudent_Num() {
        return Student_Num;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public String getID_Number() {
        return ID_Number;
    }

    public String getStreet() {
        return Street;
    }

    public String getSuburb() {
        return Suburb;
    }

    public String getCity() {
        return City;
    }

    public int getPostal_Code() {
        return Postal_Code;
    }

    public String getCell_Num() {
        return Cell_Num;
    }

    public String getEmail_Address() {
        return Email_Address;
    }

    public String getDip_Code() {
        return Dip_Code;
    }

    public String getRes_ID() {
        return Res_ID;
    }

    public String getRoom_Type() {
        return Room_Type;
    }

    public String getCampus_ID() {
        return Campus_ID;
    }

    public String getBalance() {
        return Balance;
    }

    public void setStudent_Num(int Student_Num) {
        this.Student_Num = Student_Num;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public void setID_Number(String ID_Number) {
        this.ID_Number = ID_Number;
    }

    public void setStreet(String Street) {
        this.Street = Street;
    }

    public void setSuburb(String Suburb) {
        this.Suburb = Suburb;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public void setPostal_Code(int Postal_Code) {
        this.Postal_Code = Postal_Code;
    }

    public void setCell_Num(String Cell_Num) {
        this.Cell_Num = Cell_Num;
    }

    public void setEmail_Address(String Email_Address) {
        this.Email_Address = Email_Address;
    }

    public void setDip_Code(String Dip_Code) {
        this.Dip_Code = Dip_Code;
    }

    public void setRes_ID(String Res_ID) {
        this.Res_ID = Res_ID;
    }

    public void setRoom_Type(String Room_Type) {
        this.Room_Type = Room_Type;
    }

    public void setCampus_ID(String Campus_ID) {
        this.Campus_ID = Campus_ID;
    }

    public void setBalance(String Balance) {
        this.Balance = Balance;
    }
    public String[] toArray() {
        return new String[]{String.valueOf(Student_Num),First_Name,ID_Number, Street, Suburb,  City, String.valueOf(Postal_Code) , Cell_Num,  Email_Address,  Dip_Code, Res_ID,  Room_Type,  Campus_ID,  Balance};
    }
}

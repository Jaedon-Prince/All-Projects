package za.ac.cput.mymavenproject.domain;

public class LecturerDomainClass {

    private String title;
    private String staffNumber;
    private String surname;
    private String firstName;
    private String email;
    private String department;
    private String campus;
    private String subjectCode;
    private String diplomaCode;

    public LecturerDomainClass(String title, String staffNumber, String surname, String firstName, String email, String department,String diplomaCode, String campus, String subjectCode) {
        this.title = title;
        this.staffNumber = staffNumber;
        this.surname = surname;
        this.firstName = firstName;
        this.email = email;
        this.department = department;
        this.diplomaCode=diplomaCode;
        this.campus = campus;
        this.subjectCode = subjectCode;
    }

    public LecturerDomainClass() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStaffNumber() {
        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {
        this.staffNumber = staffNumber;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getDiploma_Code() {
        return diplomaCode;
    }
        public void setDiploma_Code(String diplomaCode) {
        this.diplomaCode= diplomaCode;
    }
    public String[] toArray() {
    return new String[]{title, staffNumber, surname, firstName, email, department, diplomaCode, campus, subjectCode};
}    

}

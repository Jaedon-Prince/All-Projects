package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class DiplomaDomainClass {
    private String dipCode;
    private String campID;
    private String courseOffering;
    private String faculty;

    public DiplomaDomainClass(String dipCode, String campID, String courseOffering, String faculty) {
        this.dipCode = dipCode;
        this.campID = campID;
        this.courseOffering = courseOffering;
        this.faculty = faculty;
    }

    public DiplomaDomainClass() {}

    public String getDipCode() {
        return dipCode;
    }

    public void setDipCode(String dipCode) {
        this.dipCode = dipCode;
    }

    public String getCampID() {
        return campID;
    }

    public void setCampID(String campID) {
        this.campID = campID;
    }

    public String getCourseOffering() {
        return courseOffering;
    }

    public void setCourseOffering(String courseOffering) {
        this.courseOffering = courseOffering;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
    public String[] toArray() {
    return new String[]{dipCode, campID, courseOffering, faculty};
}
}

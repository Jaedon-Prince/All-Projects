package za.ac.cput.mymavenproject.domain;

/**
 *
 * @author camer
 */
public class PaymentsDomainClass {
    private String studentNum;
    private String lastPayment;
    private String paymentType;
    private String paymentAmount;

    public PaymentsDomainClass(String studentNum, String lastPayment, String paymentType, String paymentAmount) {
        this.studentNum = studentNum;
        this.lastPayment = lastPayment;
        this.paymentType = paymentType;
        this.paymentAmount = paymentAmount;
    }

    public PaymentsDomainClass() {}

    public String getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(String studentNum) {
        this.studentNum = studentNum;
    }

    public String getLastPayment() {
        return lastPayment;
    }

    public void setLastPayment(String lastPayment) {
        this.lastPayment = lastPayment;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.database_creation_project;

import java.sql.SQLException;
import javax.swing.SwingUtilities;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import za.ac.cput.mymavenproject.dao.CreationDAO;

/**
 *
 * @author camer
 */
public class Database_creation_project {

    public static void main(String[] args) {

        CreationDAO creationDAO = new CreationDAO();
        /*try {
            // Create tables if not exists
            //creationDAO.createTable();
            System.out.println("Table Checked/Created Successfully....");

            // Insert a row into the students table
            creationDAO.insertStudent(
                new za.ac.cput.mymavenproject.domain.DomainClass(
                    230582577,           // Student Num - int
                    "Kazuma",            // First Name - String
                    "0410265276091",     // ID Number - String
                    "Baller Street",     // Street - String
                    "Prospacicous",      // Suburb - String
                    "UA Town",           // City - String
                    7445,                // Postal Code - int
                    "0679744831",        // Cell Num - String
                    "Baller45@gmail.com",// Email - String
                    "MGICT",             // Dip Code - String
                    "001",               // Res ID - String
                    "DoubleRoom",        // Room Type - String
                    "CAMP001",           // Campus ID - String
                    "R4000"              // Balance - String
                )
            );*/
 /*creationDAO.insertStudent(
                new za.ac.cput.mymavenproject.domain.DomainClass(
                    230987654,           // Student Num
                    "Aqua",              // First Name
                    "9411285876092",     // ID Number
                    "Ocean Ave",         // Street
                    "Deepsea",           // Suburb
                    "Ocean City",        // City
                    8000,                // Postal Code
                    "0831234567",        // Cell Num
                    "aqua@gmail.com",    // Email
                    "MGCSC",             // Dip Code
                    "002",               // Res ID
                    "SingleRoom",        // Room Type
                    "CAMP002",           // Campus ID
                    "R3500"              // Balance
                )
            );
            System.out.println("Student Data Inserted Successfully....");*/
            // Insert a row into the lecturers table
            /*creationDAO.insertLecturer(
                    new za.ac.cput.mymavenproject.domain.LecturerDomainClass(
                            "Mr", // Title
                            "SN9816", // Staff Number
                            "Johnson", // Last Name
                            "Micheal", // First Name
                            "micheal.johnson@cput.ac.za", // Email
                            "Construction Management", // Department
                            "Mowbray", // Campus
                            "CMQ362S" // Course Code
                    )
            );*/
            /*creationDAO.insertLecturer(
                    new za.ac.cput.mymavenproject.domain.LecturerDomainClass(
                            "Ms", // Title
                            "SN9821", // Staff Number
                            "Smith", // Last Name
                            "Jessica", // First Name
                            "jessica.smith@cput.ac.za", // Email
                            "Computer Science", // Department
                            "Bellville", // Campus
                            "CSC204S" // Course Code
                    )
            );
            System.out.println("Lecturer Data Inserted Successfully....");

            // Insert data into the subjects table
            creationDAO.insertSubject(
                    new za.ac.cput.mymavenproject.domain.SubjectDomainClass(
                            "CSC204S", // Subject Code
                            "Computer Science", // Subject
                            "1 Year", // Duration
                            "15", // Credits
                            "R5000" // Amount
                    )
            );
            creationDAO.insertSubject(
                    new za.ac.cput.mymavenproject.domain.SubjectDomainClass(
                            "CMQ362S", // Subject Code
                            "Quantity Surveying",// Subject
                            "2 Years", // Duration
                            "20", // Credits
                            "R6000" // Amount
                    )
            );
            System.out.println("Subject Data Inserted Successfully....");

            // Insert data into the payments table
            creationDAO.insertPayments(
                    new za.ac.cput.mymavenproject.domain.PaymentsDomainClass(
                            "230582577", // Student Num
                            "2023-09-15", // Last Payment
                            "Credit Card", // Payment Type
                            "R2000" // Payment Amount
                    )
            );
            creationDAO.insertPayments(
                    new za.ac.cput.mymavenproject.domain.PaymentsDomainClass(
                            "230987654", // Student Num
                            "2023-08-20", // Last Payment
                            "EFT", // Payment Type
                            "R1000" // Payment Amount
                    )
            );
            System.out.println("Payment Data Inserted Successfully....");

            // Insert data into the classes table
            creationDAO.insertClass(
                    new za.ac.cput.mymavenproject.domain.ClassesDomainClass(
                            "CSC204S", // Subject Codes
                            "CSC204S", // Subject Code
                            "SN9821", // Staff Number
                            "Room 101", // Class Venue
                            "09:00 - 11:00" // Time Of Class
                    )
            );
            creationDAO.insertClass(
                    new za.ac.cput.mymavenproject.domain.ClassesDomainClass(
                            "CMQ362S", // Subject Codes
                            "CMQ362S", // Subject Code
                            "SN9816", // Staff Number
                            "Room 202", // Class Venue
                            "14:00 - 16:00" // Time Of Class
                    )
            );
            System.out.println("Class Data Inserted Successfully....");

            creationDAO.insertStudentMarks(
                    new za.ac.cput.mymavenproject.domain.StudentMarksDomainClass(
                            "CSC204S", // Subject Code
                            "230582577", // Student Num
                            "75", // Term 1
                            "80", // Term 2
                            "70", // Term 3
                            "85" // Term 4
                    )
            );
            creationDAO.insertStudentMarks(
                    new za.ac.cput.mymavenproject.domain.StudentMarksDomainClass(
                            "CMQ362S", // Subject Code
                            "230987654", // Student Num
                            "65", // Term 1
                            "70", // Term 2
                            "72", // Term 3
                            "68" // Term 4
                    )
            );
            System.out.println("Student Marks Data Inserted Successfully....");

            // Insert data into the residences table
            creationDAO.insertResidences(
                    new za.ac.cput.mymavenproject.domain.ResidencesDomainClass(
                            "001", // Res ID
                            "Baller Residence", // Res Name
                            "CAMP001", // Campus ID
                            "R1500", // Double Room Cost
                            "100", // Total Double Rooms
                            "20", // Available Double Rooms
                            "R2000", // Single Room Cost
                            "50", // Total Single Rooms
                            "10" // Available Single Rooms
                    )
            );
            creationDAO.insertResidences(
                    new za.ac.cput.mymavenproject.domain.ResidencesDomainClass(
                            "002", // Res ID
                            "Ocean View Residence", // Res Name
                            "CAMP002", // Campus ID
                            "R1400", // Double Room Cost
                            "120", // Total Double Rooms
                            "25", // Available Double Rooms
                            "R2100", // Single Room Cost
                            "60", // Total Single Rooms
                            "12" // Available Single Rooms
                    )
            );
            System.out.println("Residences Data Inserted Successfully....");

            // Insert data into the campus table
            creationDAO.insertCampus(
                    new za.ac.cput.mymavenproject.domain.CampusDomainClass(
                            "CAMP001", // Campus ID
                            "UA Town", // Location
                            "Baller Street", // Street Name
                            "Library, Sports Center", // Facilities
                            "1995" // Established
                    )
            );
            creationDAO.insertCampus(
                    new za.ac.cput.mymavenproject.domain.CampusDomainClass(
                            "CAMP002", // Campus ID
                            "Ocean City", // Location
                            "Ocean Ave", // Street Name
                            "Library, Swimming Pool, Gym", // Facilities
                            "2000" // Established
                    )
            );
            System.out.println("Campus Data Inserted Successfully....");

            // Insert data into the diploma table
            creationDAO.insertDiploma(
                    new za.ac.cput.mymavenproject.domain.DiplomaDomainClass(
                            "MGICT", // Diploma Code
                            "CAMP001", // Campus ID
                            "Communication Technology", // Course Offering
                            "Informatics and Design" // Faculty
                    )
            );
            creationDAO.insertDiploma(
                    new za.ac.cput.mymavenproject.domain.DiplomaDomainClass(
                            "MGCSC", // Diploma Code
                            "CAMP002", // Campus ID
                            "Computer Science", // Course Offering
                            "Applied Sciences" // Faculty
                    )
            );
            System.out.println("Diploma Data Inserted Successfully....");

            // Insert data into the subjects table
            creationDAO.insertSubject(
                    new za.ac.cput.mymavenproject.domain.SubjectDomainClass(
                            "CSC204S", // Subject Code
                            "Computer Science", // Subject
                            "1 Year", // Duration
                            "15", // Credits
                            "R5000" // Amount
                    )
            );
            creationDAO.insertSubject(
                    new za.ac.cput.mymavenproject.domain.SubjectDomainClass(
                            "CMQ362S", // Subject Code
                            "Quantity Surveying", // Subject
                            "2 Years", // Duration
                            "20", // Credits
                            "R6000" // Amount
                    )
            );
            System.out.println("Subject Data Inserted Successfully....");

        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }*/
    }
}

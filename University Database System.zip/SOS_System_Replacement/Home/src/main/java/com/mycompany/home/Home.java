/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.home;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

/**
 *
 * @author S
 */
public class Home {

    //Login and registration stuff start
    // Use ArrayLists instead of arrays for dynamic addition
    private static ArrayList<String> usernames = new ArrayList<>();
    private static ArrayList<String> passwords = new ArrayList<>();

    // Variables to store user details
    private static String userStudentNumber, userfullName, userClassGroup, userdateOfBirth, useraddress, userphoneNumber;

    //Login and registration stuff end
    private JFrame frame;
    private JPanel topPanel;
    private JPanel centerPanel;
    private JPanel bottomPanel;
    private JPanel homePanel;
    private JLabel lecturerImgLbl;
    private JLabel aimImgLbl;
    private JLabel lecturerLbl;
    private JLabel lecturerInfoLbl;
    private JLabel aimLbl;
    private JLabel aimInfoLbl;
    private JButton lecturerBtn;
    private JButton aimBtn;
    private static Home instance;
    sosGUI mainGUI = new sosGUI();
    ImageIcon headerImage = new ImageIcon(sosGUI.class.getResource("resources\\images\\better sos.PNG")); // Ensure your image path is correct

    ImageIcon footerIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\cputLogo.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH));

    ImageIcon twitIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296516_tweet_twitter_twitter logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
    ImageIcon instaIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296765_camera_instagram_instagram logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
    ImageIcon fBIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5365678_fb_facebook_facebook logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));

    ImageIcon linkinIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296501_linkedin_network_linkedin logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));

    //FOOTER
    JLabel insta = new JLabel(instaIcon);
    JLabel fB = new JLabel(fBIcon);
    JLabel linkin = new JLabel(linkinIcon);
    JLabel twit = new JLabel(twitIcon);
    JLabel smallLogo = new JLabel(footerIcon);

    public static void main(String[] args) {
        instance = new Home();
    }

    public static Home getInstance() {
        return instance;
    }

    public Home() {
        // Step 1: Create the main JFrame
        frame = new JFrame("BetterSOS");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 1000); // Set the size of the window
        frame.setLayout(new BorderLayout());

        // Step 2: Initialize HomePage (part of this class)
        initHomePage();

        frame.setVisible(true); // Make the window visible
    }

    private void initHomePage() {
        homePanel = new JPanel(new BorderLayout());
        topPanel = new JPanel();

        centerPanel = new JPanel(new GridBagLayout());

        bottomPanel = new JPanel(new GridBagLayout());
        JLabel footerHomeLbl = new JLabel();
        JLabel headerHomeLbl = new JLabel(headerImage);

        ImageIcon lectIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\education_3976625.png")).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
        ImageIcon aimIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\work-process_3281345.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH));
        ImageIcon aimInfoIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\aim.png")).getImage().getScaledInstance(230, 130, Image.SCALE_DEFAULT));
        ImageIcon aboutUsIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\about.png")).getImage().getScaledInstance(230, 130, Image.SCALE_SMOOTH));
        ImageIcon vscIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\log_8861558.png")).getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH));
        JLabel vscInfoLbl = new JLabel("<html><ul><u><b>Virtual Student Card <u><b><br><br>"
                + "Register to access your Virtual Student Card.<br>"
                + "<b>Access to:<b>"
                + "<div style='margin-left: 30px;'><li>Campus</li>"
                + "<li>Exam Venues</li>"
                + "<li>Shuttles</li>"
                + "<b><blockquote> All on your cell phone.</blockquote><b></ul></div></html>");
        vscInfoLbl.setFont(new Font("Courier New", Font.BOLD, 15));
        JLabel aimLbl = new JLabel("<html><p><u><b>Our Aim </u><b><br> <br>BetterSOS is designed to revolutionize <br> student access to resource, offering a <br> user-friendly platform for academic <br>support  and beyond. </p><html>");
        aimLbl.setFont(new Font("Courier New", Font.BOLD, 15));

        JLabel aboutLbl = new JLabel("<html><p><b><u>About Us <br><br></u> BetterSOS is a comprehensive platform designed to <br> streamline administrative services for both students and staff. <br> Our app simplifies processes such as course registration, <br>fee management, residence allocation, and lecturer scheduling.<b></p><html>");
        aboutLbl.setFont(new Font("Courier New", Font.BOLD, 16));
        JLabel aimInfoLbl = new JLabel(aimInfoIcon);
        JLabel aboutUsLbl = new JLabel(aboutUsIcon);
        JLabel vscLbl = new JLabel(vscIcon);
        JLabel lecturerImgLbl = new JLabel(lectIcon);
        JLabel aimImgLbl = new JLabel(aimIcon);
        JButton lecturerBtn = new JButton("Click Here");
        JButton aimBtn = new JButton("More");
        JButton regHomeButton = new JButton("Register");
        JButton loginHomeButton = new JButton("Login");

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.BOTH;  // Allow components to fill the space

        gbc.gridx = 0;
        gbc.gridy = 1;

        gbc.anchor = GridBagConstraints.LINE_START; // Align label to the left
        gbc.insets = new Insets(0, 0, 0, 60); // Add padding
        centerPanel.add(aimLbl, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;

        gbc.anchor = GridBagConstraints.CENTER;
        centerPanel.add(aimImgLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;

        gbc.insets = new Insets(0, 0, 0, 0); // Add padding
        centerPanel.add(lecturerImgLbl, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;

        gbc.insets = new Insets(0, 0, 0, 20); // Add padding
        centerPanel.add(vscLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;

        gbc.anchor = GridBagConstraints.LINE_START; // Center the about label
        // gbc.insets = new Insets(5, 5, 5, 5); // Add padding
        centerPanel.add(aboutLbl, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // VSC Info Label spans 2 cells
        gbc.anchor = GridBagConstraints.WEST; // Align to the left
        //  gbc.insets = new Insets(5, 5, 5, 5); // Add padding
        centerPanel.add(vscInfoLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 0;  // Make the components expand horizontally
        gbc.weighty = 0;
        gbc.gridwidth = 2; // Button spans 2 cells
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER; // Center the button
        //   gbc.insets = new Insets(5, 5, 5, 5); // Add padding

        centerPanel.add(regHomeButton, gbc);
        
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.weightx = 0;  // Make the components expand horizontally
        gbc.weighty = 0;
        gbc.gridwidth = 2; // Button spans 2 cells
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER; // Center the button
        //   gbc.insets = new Insets(5, 5, 5, 5); // Add padding

        centerPanel.add(loginHomeButton, gbc);

//
//        gbc.gridx = 2;
//        gbc.gridy = 0;
//        //   gbc.anchor = GridBagConstraints.LINE_END;
//        bottomPanel.add(smallLogo, gbc);
        topPanel.setBackground(new Color(0, 0, 102));
        centerPanel.setBackground(Color.WHITE);
        bottomPanel.setPreferredSize(new Dimension(80, 29));
        bottomPanel.setBackground(new Color(0, 0, 102));

        topPanel.add(headerHomeLbl);
        bottomPanel.add(footerHomeLbl);

        // Wrap the centerPanel with a JScrollPane
    JScrollPane scrollPane = new JScrollPane(centerPanel);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    homePanel.add(topPanel, BorderLayout.NORTH);
    homePanel.add(scrollPane, BorderLayout.CENTER); // Add the scroll pane to the center
    homePanel.add(bottomPanel, BorderLayout.SOUTH);

        regHomeButton.addActionListener(e -> {
            frame.getContentPane().removeAll(); // Clear current content
            initRegistrationPage();  // Switch to the Login page
            frame.revalidate(); // Refresh the frame
            frame.repaint();    // Redraw the frame
        });
        loginHomeButton.addActionListener(e -> {
            frame.getContentPane().removeAll(); // Clear current content
            initLoginPage();  // Switch to the Login page
            frame.revalidate(); // Refresh the frame
            frame.repaint();    // Redraw the frame
            
        });
        
        

        frame.add(homePanel);
    }

    private void initLoginPage() {
        JLabel opaLbl = new JLabel("<html><a href =''>OPA</a></html>");
        opaLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel bbLbl = new JLabel("<html><a href=''>BlackBoard</a></html>");
        bbLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel websiteLbl = new JLabel("<html><a href=''>CPUT Website</a></html>");
        websiteLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel libraryLbl = new JLabel("<html><a href=''>Library</a></html>");
        libraryLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JPanel loginPanel = new JPanel(new BorderLayout());
        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");
        JButton backButton = new JButton("Back");

        JPanel topPnlLogin = new JPanel();
        JPanel centerPnlLogin = new JPanel(new GridBagLayout());
        JPanel bottomPnlLogin = new JPanel();

        JComboBox<String> roleLoginCmbo = new JComboBox<>(new String[]{"Student", "Admin"});

        JLabel headerLblLog = new JLabel(headerImage);
        JLabel footerLblLog = new JLabel();
        JLabel usernameLbl = new JLabel("Username: ");
        JLabel passwordLbl = new JLabel("Password: ");
        JLabel roleLbl = new JLabel("Login As: ");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.BOTH;

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        centerPnlLogin.add(roleLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(roleLoginCmbo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(usernameLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(passwordLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(passwordField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(loginButton, gbc);
        
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlLogin.add(backButton, gbc);

        //FOOTER
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
//
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(smallLogo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        bottomPnlLogin.add(linkin, gbc);

        linkin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        linkin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://za.linkedin.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(insta, gbc);

        insta.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        insta.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(fB, gbc);

        fB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        fB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://web.facebook.com/?_rdc=1&_rdr"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
//
        gbc.gridx = 5;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(twit, gbc);
        twit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        twit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://x.com/?lang=en"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 6;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(websiteLbl, gbc);
        websiteLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 7;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(bbLbl, gbc);

        bbLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://myclassroom.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

//        
        gbc.gridx = 8;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlLogin.add(opaLbl, gbc);
        opaLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://opa.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        topPnlLogin.setBackground(new Color(0, 0, 102));
        centerPnlLogin.setBackground(Color.WHITE);
        bottomPnlLogin.setBackground(Color.WHITE);

        topPnlLogin.add(headerLblLog);
        bottomPanel.add(footerLblLog);

        loginPanel.add(topPnlLogin, BorderLayout.NORTH);
        loginPanel.add(centerPnlLogin, BorderLayout.CENTER);
        loginPanel.add(bottomPnlLogin, BorderLayout.SOUTH);

        loginButton.addActionListener(e -> {
            loadUsersFromFile();
            String selectedUserType = roleLoginCmbo.getSelectedItem().toString(); // Get the selected user type
            // Check if the username is provided and proceed with the login
             String enteredUsername = usernameField.getText();
            String enteredPassword = new String(passwordField.getPassword());
            
                        // Check if the username and password are provided
            if (enteredUsername.equals("") || enteredPassword.equals("")) {
                JOptionPane.showMessageDialog(frame, "Username and Password cannot be skibidi", "Login jonkled", JOptionPane.ERROR_MESSAGE);
                return;
            }
         //   if (usernameField.getText().equals("")) {
if (usernames.contains(enteredUsername) && passwords.get(usernames.indexOf(enteredUsername)).equals(enteredPassword)) {
                // Clear current content
                frame.getContentPane().removeAll();
                mainGUI.showMainGUI(frame);

                // Show the main GUI based on user type
                showMainGUI(selectedUserType);

                // Refresh the frame to display new content
                frame.revalidate();
                frame.repaint();
            } else {
                JOptionPane.showMessageDialog(frame, "Login Failed");
            }
        });
        
        backButton.addActionListener(e -> {
          frame.getContentPane().removeAll();
            frame.getContentPane().removeAll(); // Clear current content
            initHomePage();  // Switch to the Login page
            frame.revalidate(); // Refresh the frame
            frame.repaint();    // Redraw the frame
        });
        
        

        frame.add(loginPanel);

    }

    private void initRegistrationPage() {
        JLabel opaLbl = new JLabel("<html><a href =''>OPA</a></html>");
        opaLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel bbLbl = new JLabel("<html><a href=''>BlackBoard</a></html>");
        bbLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel websiteLbl = new JLabel("<html><a href=''>CPUT Website</a></html>");
        websiteLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel libraryLbl = new JLabel("<html><a href=''>Library</a></html>");
        libraryLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand
        JPanel topPnlReg = new JPanel();
        JPanel centerPnlReg = new JPanel(new GridBagLayout());
        JPanel bottomPnlReg = new JPanel();
        JPanel registrationPanel = new JPanel(new BorderLayout());
        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"Student", "Admin"});
        JTextField studentNumber = new JTextField(20);
        JTextField fullName = new JTextField(20);
        JTextField classGroup = new JTextField(20);
        JTextField birth = new JTextField(20);
        JTextField address = new JTextField(20);
        JTextField phoneNumber = new JTextField(20);

        JLabel headerLbl = new JLabel(headerImage);
        JLabel footerLbl = new JLabel();
        JLabel usernameLbl = new JLabel("Username: ");
        JLabel passwordLbl = new JLabel("Password: ");
        JLabel roleLbl = new JLabel("Register As: ");
        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");
        JLabel studentNumberLbl = new JLabel("Student Number:");
        JLabel fullNameLbl = new JLabel("Full Name:");
        JLabel classGroupLbl = new JLabel("Class:");
        JLabel birthLbl = new JLabel("D.O.B:");
        JLabel addressLbl = new JLabel("Address:");
        JLabel phoneNumberLbl = new JLabel("Phone Number:");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.BOTH;

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        centerPnlReg.add(roleLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(roleComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(usernameLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(passwordLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(passwordField, gbc);

        // Adding Student Number Label and Field
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(studentNumberLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(studentNumber, gbc);

// Adding Full Name Label and Field
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(fullNameLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(fullName, gbc);

// Adding Class Group Label and Field
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(classGroupLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(classGroup, gbc);

// Adding Date of Birth (D.O.B) Label and Field
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(birthLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(birth, gbc);

// Adding Address Label and Field
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(addressLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 8;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(address, gbc);

// Adding Phone Number Label and Field
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(phoneNumberLbl, gbc);

        gbc.gridx = 1;
        gbc.gridy = 9;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(phoneNumber, gbc);

        gbc.gridx = 1;
        gbc.gridy = 10;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(registerButton, gbc);
        
        gbc.gridx = 2;
        gbc.gridy = 10;
        gbc.anchor = GridBagConstraints.LINE_START;
        centerPnlReg.add(backButton, gbc);

        //FOOTER
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
//
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(smallLogo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        bottomPnlReg.add(linkin, gbc);

        linkin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        linkin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://za.linkedin.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(insta, gbc);

        insta.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        insta.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(fB, gbc);

        fB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        fB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://web.facebook.com/?_rdc=1&_rdr"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
//
        gbc.gridx = 5;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(twit, gbc);

        twit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        twit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://x.com/?lang=en"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 6;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(websiteLbl, gbc);
        websiteLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 7;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPnlReg.add(bbLbl, gbc);

        bbLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://myclassroom.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

//        
        gbc.gridx = 8;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        bottomPanel.add(opaLbl, gbc);
        opaLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://opa.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        topPnlReg.setBackground(new Color(0, 0, 102));
        centerPnlReg.setBackground(Color.WHITE);
        bottomPnlReg.setBackground(Color.WHITE);

        topPnlReg.add(headerLbl);
        bottomPnlReg.add(footerLbl);
        registrationPanel.add(topPnlReg, BorderLayout.NORTH);
        registrationPanel.add(centerPnlReg, BorderLayout.CENTER);
        registrationPanel.add(bottomPnlReg, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> {
            loadUsersFromFile();

            String enteredUsername = usernameField.getText();
            String enteredPassword = new String(passwordField.getPassword());

            // Get other user details
            userStudentNumber = studentNumber.getText();
            userfullName = fullName.getText();
            userClassGroup = classGroup.getText();
            userdateOfBirth = birth.getText();
            useraddress = address.getText();
            userphoneNumber = phoneNumber.getText();
            // Check if any field is empty
            if (enteredUsername.isEmpty() || enteredPassword.isEmpty()
                    || userStudentNumber.isEmpty() || userfullName.isEmpty()
                    || userClassGroup.isEmpty() || userdateOfBirth.isEmpty()
                    || useraddress.isEmpty() || userphoneNumber.isEmpty()) {

                // Show an error message if any field is empty
                JOptionPane.showMessageDialog(frame, "All fields must be filled Mr Skibidi man", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Stop further execution if any field is empty
            }

            // Check if username already exists
            if (usernames.contains(enteredUsername)) {
                JOptionPane.showMessageDialog(frame, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            // Check if password is longer than 8 characters
            if (enteredPassword.length() < 8) {
                JOptionPane.showMessageDialog(frame, "Password must be at least 8 characters long!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            // Add username and password to the lists
            usernames.add(enteredUsername);
            passwords.add(enteredPassword);

            // Save the new user details to the file
            saveUserToFile(enteredUsername, enteredPassword);
            
            //student card generation
   /*     // Get the path of the input image (student template)
        String imagePath =       "E:\\UNI IT\\2nd Year\\Projects\\CODING\\For final\\Where the magic hopefully happens\\18 October\\Home\\student_template.jpg"; // path to the input image
        String outputImagePath = "E:\\UNI IT\\2nd Year\\Projects\\CODING\\For final\\Where the magic hopefully happens\\18 October\\Home\\output.jpg"; // path to the output image
                    try {
            File inputFile = new File(imagePath);
            BufferedImage image = ImageIO.read(inputFile);

            Graphics2D g2d = image.createGraphics();
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            
            // Draw name
            g2d.drawString( userfullName, 280, 174);
            // Draw surname
            g2d.drawString( userClassGroup, 280, 190);
            // Draw student number
            g2d.drawString(userStudentNumber , 280, 156);
            
            g2d.drawString(userdateOfBirth, 280, 208);
            
            g2d.drawString(useraddress, 290, 225);
            
            g2d.drawString(userphoneNumber, 285, 242);
            
            g2d.dispose();

            File outputFile = new File(outputImagePath);
            ImageIO.write(image, "jpg", outputFile);

            System.out.println("Image with text added successfully.");
        } catch (Exception er) {
            System.out.println("Error: " + er.getMessage());
        }
            //student card generation end
*/
   //hopefully the good way start
   // Get the path of the input image (student template)
try (InputStream input = getClass().getClassLoader().getResourceAsStream("com/mycompany/home/resources/images/student_template.jpg")) {
    if (input == null) {
        System.out.println("Sorry, unable to find student_template.jpg");
        return;
    }

    // Read the image from the input stream
    BufferedImage image = ImageIO.read(input);

    // Your existing drawing code here...
            Graphics2D g2d = image.createGraphics();
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            
            // Draw name
            g2d.drawString( userfullName, 280, 174);
            // Draw surname
            g2d.drawString( userClassGroup, 280, 190);
            // Draw student number
            g2d.drawString(userStudentNumber , 280, 156);
            
            g2d.drawString(userdateOfBirth, 280, 208);
            
            g2d.drawString(useraddress, 290, 225);
            
            g2d.drawString(userphoneNumber, 285, 242);
            
            g2d.dispose();
    // Define the output path
    File outputFile = new File("src/main/resources/com/mycompany/home/resources/images/output.jpg");
    // Ensure the parent directory exists
    outputFile.getParentFile().mkdirs();

    // Write the image to the output file
    ImageIO.write(image, "jpg", outputFile);
    
    System.out.println("Image with text added successfully.");
} catch (Exception er) {
    System.out.println("Error: " + er.getMessage());
}
   
   //hopefully the good way end
            JOptionPane.showMessageDialog(frame, "Registration Successful! Logging you in...", "Success", JOptionPane.INFORMATION_MESSAGE);
            frame.getContentPane().removeAll(); // Clear current content
            initLoginPage();  // Switch to the Login page
            frame.revalidate(); // Refresh the frame
            frame.repaint();    // Redraw the frame
        });
     
        backButton.addActionListener(e -> {
         frame.getContentPane().removeAll(); // Clear current content
            initHomePage();  // Switch to the Login page
            frame.revalidate(); // Refresh the frame
            frame.repaint();    // Redraw the frame   
        });
        
        
        frame.add(registrationPanel);
    }

    private void showMainGUI(String userType) {

        // Create a new sosGUI instance
        // Access the main tabbed pane
        JTabbedPane mainTab = mainGUI.mainTab;

        // Clear the main tab to start fresh
        mainTab.removeAll();

        if (userType.equals("Student")) {
            // Only add the student tab
            mainTab.addTab("Student", mainGUI.studentNest); // Add Student tab only
        } else if (userType.equals("Admin")) {
            // Add both admin and student tabs for admin users
            mainTab.addTab("Student", mainGUI.studentNest); // Add Student tab
            mainTab.addTab("ADMIN", mainGUI.adminNest);     // Add Admin tab
        }
        frame.setBackground(Color.WHITE);
        // Add the main tabbed pane to the frame
        frame.add(mainTab, BorderLayout.CENTER);

        // Revalidate and repaint the frame to apply the changes
        frame.revalidate();
        frame.repaint();
    }
    // Function to load users from the text file

    private static void loadUsersFromFile() {
        File file = new File("users.txt");
        if (file.exists()) {
            try (Scanner scanner = new Scanner(file)) {
                while (scanner.hasNextLine()) {
                    String[] userData = scanner.nextLine().split(",");
                    if (userData.length == 2) {
                        usernames.add(userData[0]);
                        passwords.add(userData[1]);
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("File not found: " + e.getMessage());
            }
        }
    }

    // Function to save user details to the text file
    private static void saveUserToFile(String username, String password) {
        try (FileWriter writer = new FileWriter("users.txt", true)) {
            writer.write(username + "," + password + "\n");
        } catch (IOException e) {
            System.out.println("Error saving user to file: " + e.getMessage());
        }
    }

    // If you want to go back to Home Page 
    public void showHomePage() {
        frame.getContentPane().removeAll();
        initHomePage(); // Recreate the HomePage
        frame.revalidate();
        frame.repaint();
    }
}

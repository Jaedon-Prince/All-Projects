/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.home;

import za.ac.cput.mymavenproject.dao.CreationDAO;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import za.ac.cput.mymavenproject.domain.CampusDomainClass;
import za.ac.cput.mymavenproject.domain.ClassesDomainClass;
import za.ac.cput.mymavenproject.domain.DiplomaDomainClass;
import za.ac.cput.mymavenproject.domain.DomainClass;
import za.ac.cput.mymavenproject.domain.LecturerDomainClass;
import za.ac.cput.mymavenproject.domain.ResidencesDomainClass;
import za.ac.cput.mymavenproject.domain.StudentMarksDomainClass;
import za.ac.cput.mymavenproject.domain.SubjectDomainClass;

/**
 *
 * @author S
 */
public class sosGUI extends JPanel {

    CreationDAO creationDAO = new CreationDAO();

    JTabbedPane mainTab = new JTabbedPane();

    JTabbedPane studentNest = new JTabbedPane();
    JTabbedPane adminNest = new JTabbedPane();

    //imgae nonsense
    JPanel mainTopPanel, mainBottomPanel;
    JLabel mainHeaderLbl, insta, twit, linkin, fB, smallLogo;

    JPanel studFees = new JPanel(new GridBagLayout());
    JPanel adminFees = new JPanel(new GridBagLayout());

    //Subject Pages Stuff
    JTabbedPane studSubjMain = new JTabbedPane();
    JTabbedPane adminSubjMain = new JTabbedPane();

    Layouts layout = new Layouts();

    public sosGUI() {
        setLayout(new BorderLayout());
        //MORE IMAGE NONSENSE
        mainTopPanel = new JPanel();
        mainBottomPanel = new JPanel(new GridBagLayout());
        ImageIcon headerImage = new ImageIcon(sosGUI.class.getResource("resources\\images\\better sos.PNG")); // Ensure your image path is correct
        ImageIcon footerIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\cputLogo.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH));
        //social media stuff
        ImageIcon twitIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296516_tweet_twitter_twitter logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
        ImageIcon instaIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296765_camera_instagram_instagram logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
        ImageIcon fBIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5365678_fb_facebook_facebook logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
        ImageIcon linkinIcon = new ImageIcon(new ImageIcon(sosGUI.class.getResource("resources\\images\\5296501_linkedin_network_linkedin logo_icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));

        mainHeaderLbl = new JLabel(headerImage);
        //FOOTER
        insta = new JLabel(instaIcon);
        fB = new JLabel(fBIcon);
        linkin = new JLabel(linkinIcon);
        twit = new JLabel(twitIcon);
        smallLogo = new JLabel(footerIcon);

        // Adding nested tabs to student tabbed pane
        studentNest.addTab("Student", layout.studStudentPanelLayout());
        adminNest.addTab("Student (ADMIN)", layout.adminStudentLayout());

        // Adding nested tabs to residence tabbed pane
        studentNest.addTab("Residence", layout.studResLayout());
        adminNest.addTab("Residence (ADMIN)", layout.adminResLayout());

        // Adding nested tabs to lecturer tabbed pane
        studentNest.addTab("Lecturer", layout.studLectLayout());
        adminNest.addTab("Lecturer (ADMIN)", layout.adminLectLayout());

        // Adding nested tabs to subject tabbed pane
        studSubjMain.add("Student View", layout.studSubjLayout());
        studSubjMain.add("Subject Marks", layout.studMarksLayout());
        adminSubjMain.add("Admin View", layout.adminSubjLayout());
        adminSubjMain.add("Subject Marks (ADMIN)", layout.adminMarksLayout());
        studentNest.addTab("Subject", studSubjMain);
        adminNest.addTab("Subject (ADMIN)", adminSubjMain);

        // Adding nested tabs to diploma tabbed pane
        studentNest.addTab("Diploma", layout.studDipLayout());
        adminNest.addTab("Diploma (ADMIN)", layout.adminDipLayout());

        // Adding nested tabs to campus tabbed pane
        studentNest.addTab("Campus", layout.studCampusLayout());
        adminNest.addTab("Campus (ADMIN)", layout.adminCampusLayout());

        // Adding nested tabs to fees tabbed pane
        studentNest.addTab("Fees", studFees);
        adminNest.addTab("Fees (ADMIN)", adminFees);

        // Add the nested tabbed panes to the main tabbed pane
        mainTab.addTab("Student", studentNest);
        mainTab.addTab("ADMIN", adminNest);
        mainTopPanel.setBackground(new Color(0, 0, 102));
        mainBottomPanel.setBackground(Color.WHITE);

        mainTopPanel.add(mainHeaderLbl);
        mainTopPanel.setPreferredSize(new Dimension(getWidth(), 120));  // Set fixed height for header
        mainBottomPanel.setPreferredSize(new Dimension(getWidth(), 150));
        mainTab.setPreferredSize(new Dimension(1000, 750));
        mainTab.setBackground(Color.WHITE);

        add(mainTopPanel, BorderLayout.NORTH);
        add(mainTab, BorderLayout.CENTER);

        add(mainBottomPanel, BorderLayout.SOUTH);

        //action listeners
        Layouts.addStudBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openStudDialog(null); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addStudBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openStudAdminDialog(null); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addResBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openStudResDialog(); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addResBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAdminResDialog(null); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addSubBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAdminSubjDialog(null); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addMarksBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMarksInputDialog(null); // Open dialog for adding a new lecturer
            }
        });
        Layouts.addSubBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openstudSubjDialog(); // Open dialog for adding a new lecturer
            }
        });

        Layouts.addCampBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCampusDialog(null); // Open dialog for adding a new campus
            }
        });

        Layouts.addDipBtnAD.addActionListener((ActionEvent e) -> {
            dipAdminDialog(null); // Open dialog for adding a new diploma
        });

        Layouts.addLectBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lectAdminDialog(null); // Open dialog for adding a new lecturer
            }
        });

        Layouts.updateCampBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //hmmmmmmmmmmmm  
            }
        });
        Layouts.updateCampBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableCampAD.getSelectedRow();
                if (selectedRow != -1) {
                    CampusDomainClass selectedCampus = getSelectedCampus(selectedRow);
                    openCampusDialog(selectedCampus);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a lecturer to update.");
                }
            }
        });
        Layouts.updateDipBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        Layouts.updateDipBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableDipAD.getSelectedRow(); // Check selected row for diplomas
                if (selectedRow != -1) {
                    DiplomaDomainClass selectedDiploma = getSelectedDiploma(selectedRow);
                    dipAdminDialog(selectedDiploma);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a diploma to update.");
                }
            }
        });
        Layouts.updateLectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //no
            }
        });
        Layouts.updateLectBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableLectAD.getSelectedRow(); // Check selected row for lecturers
                if (selectedRow != -1) {
                    LecturerDomainClass selectedLecturer = getSelectedLecturer(selectedRow);
                    lectAdminDialog(selectedLecturer);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a lecturer to update.");
                }
            }
        });
        Layouts.updateMarksBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        Layouts.updateMarksBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableMarksAD.getSelectedRow(); // Check selected row for student marks
                if (selectedRow != -1) {
                    StudentMarksDomainClass selectedMarks = getSelectedStudentMarks(selectedRow);
                    openMarksInputDialog(selectedMarks);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select student marks to update.");
                }
            }
        });
        Layouts.updateResBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
            openStudResDialog();
            }
        });
        Layouts.updateResBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableResAD.getSelectedRow(); // Check selected row for residences
                if (selectedRow != -1) {
                    ResidencesDomainClass selectedResidences = getSelectedResidences(selectedRow);
                    openAdminResDialog(selectedResidences);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a residence to update.");
                }
            }
        });
        Layouts.updateStudBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableStud.getSelectedRow(); // Check selected row for students
                if (selectedRow != -1) {
                    DomainClass selectedStudent = getSelectedStudent(selectedRow);
                    openStudDialog(selectedStudent);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a student to update.");
                }
            }
        });
        Layouts.updateStudBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableStudAD.getSelectedRow(); // Check selected row for admin students
                if (selectedRow != -1) {
                    DomainClass selectedStudent = getSelectedStudent(selectedRow);
                    openStudAdminDialog(selectedStudent);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a student to update.");
                }
            }
        });
        Layouts.updateSubBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        Layouts.updateSubBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = Layouts.tableSubAD.getSelectedRow(); // Check selected row for subjects
                if (selectedRow != -1) {
                    SubjectDomainClass selectedSubject = getSelectedSubject(selectedRow);
                    openAdminSubjDialog(selectedSubject);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a subject to update.");
                }
            }
        });
        

        Layouts.dltCampBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
        Layouts.dltCampBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
         int selectedRow = Layouts.tableCampAD.getSelectedRow();
         if (selectedRow != -1) {
          try{   
          String campID = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 0); 
          CreationDAO.deleteCampus(campID);
                    displayAllCampuses(); // Refresh the table
          }catch (SQLException E){
          System.out.println("ERROR: " + E);    
          }     
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a Campus to delete.");
                }
            }
        });
        Layouts.dltDipBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        Layouts.dltDipBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableDipAD.getSelectedRow(); // Get the selected row from the Diploma table
        if (selectedRow != -1) {
            try {
                String dipCode = (String) Layouts.tableModelDipAD.getValueAt(selectedRow, 0); // Get the diploma code from the selected row
                CreationDAO.deleteDiploma(dipCode); // Call the DAO method to delete the diploma
                displayAllDiplomas(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }     
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Diploma to delete."); // Alert if no row is selected
        }
    }
});
        Layouts.dltLectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
Layouts.dltLectBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableLectAD.getSelectedRow(); // Get the selected row from the Lecturer table
        if (selectedRow != -1) {
            try {
                String staffNumber = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 4); 
                CreationDAO.deleteLecturer(staffNumber); // Call the DAO method to delete the lecturer
                displayAllLecturers(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Lecturer to delete."); // Alert if no row is selected
        }
    }
});
        Layouts.dltMarksBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
Layouts.dltMarksBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableMarksAD.getSelectedRow(); // Get the selected row from the Marks table
        if (selectedRow != -1) {
            try {
               // String studentNum = (String) Layouts.tableModelMarks.getValueAt(selectedRow, 1); // Get the student number from the selected row
                String subCode = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 0); // Get the subject code from the selected row
                CreationDAO.deleteStudentMarks(subCode); // Call the DAO method to delete the marks
                displayAllStudentMarks(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select Marks to delete."); // Alert if no row is selected
        }
    }
});
        Layouts.dltResBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
        deleteStudRes();
            }
        });
Layouts.dltResBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableResAD.getSelectedRow(); // Get the selected row from the Residences table
        if (selectedRow != -1) {
            try {
                String resID = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 0); // Get the residence ID from the selected row
                CreationDAO.deleteResidences(resID); // Call the DAO method to delete the residence
                displayAllResidences(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Residence to delete."); // Alert if no row is selected
        }
    }
});
Layouts.dltStudBtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableStud.getSelectedRow(); // Get the selected row from the Student table
        if (selectedRow != -1) {
            try {
                String studentNum = (String) Layouts.tableModelStud.getValueAt(selectedRow, 0); // Get the student number from the selected row
                CreationDAO.deleteStudent(Integer.parseInt(studentNum)); // Call the DAO method to delete the student
                displayAllStudents(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Student to delete."); // Alert if no row is selected
        }
    }
});
Layouts.dltStudBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableStudAD.getSelectedRow(); // Get the selected row from the Admin Student table
        if (selectedRow != -1) {
            try {
                String studentNum = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 0); // Get the student number from the selected row
                CreationDAO.deleteStudent(Integer.parseInt(studentNum)); // Call the DAO method to delete the student
                displayAllStudents(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Student to delete."); // Alert if no row is selected
        }
    }
});
        Layouts.dltSubBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
Layouts.dltSubBtnAD.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = Layouts.tableSubAD.getSelectedRow(); // Get the selected row from the Subject table
        if (selectedRow != -1) {
            try {
                String subjectCode = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 0); // Get the subject code from the selected row
                CreationDAO.deleteSubject(subjectCode); // Call the DAO method to delete the subject
                displayAllSubjects(); // Refresh the table to show the updated list
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex); // Print any SQL exceptions to the console
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Subject to delete."); // Alert if no row is selected
        }
    }
});
        Layouts.displayCampBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllCampuses();
            }
        });
        Layouts.displayCampBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllCampuses();
            }
        });
        Layouts.displayDipBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllDiplomas();
            }
        });
        Layouts.displayDipBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllDiplomas();
            }
        });
        Layouts.displayLectBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllLecturers();
            }
        });
        Layouts.displayLectBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllLecturers();
            }
        });
        Layouts.displayMarksBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllStudentMarks();
            }
        });
        Layouts.displayMarksBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllStudentMarks();
            }
        });
        Layouts.displayResBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllResidences();
            }
        });
        Layouts.displayResBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllResidences();
            }
        });
        Layouts.displayStudBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllStudents();
            }
        });
        Layouts.displayStudBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllStudents();
            }
        });
        Layouts.displaySubBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllSubjects();

            }
        });
        Layouts.displaySubBtnAD.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllSubjects();

            }
        });
        Layouts.searchCampBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchCampFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<CampusDomainClass> campuses = CreationDAO.searchCampus(keyword);
                    Layouts.tableModelCamp.setRowCount(0);
                    if (!campuses.isEmpty()) {
                        for (CampusDomainClass campus : campuses) {
                            Layouts.tableModelCamp.addRow(campus.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Campuses found.");
                    }
                }
            }
        });
// Admin Search Campus Button
        Layouts.searchCampBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchCampFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<CampusDomainClass> campuses = CreationDAO.searchCampus(keyword);
                    Layouts.tableModelCampAD.setRowCount(0);
                    if (!campuses.isEmpty()) {
                        for (CampusDomainClass campus : campuses) {
                            Layouts.tableModelCampAD.addRow(campus.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Campuses found.");
                    }
                }
            }
        });
// Search Diploma Button
        Layouts.searchDipBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchDipFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<DiplomaDomainClass> diplomas = CreationDAO.searchDiploma(keyword);
                    Layouts.tableModelDip.setRowCount(0);
                    if (!diplomas.isEmpty()) {
                        for (DiplomaDomainClass diploma : diplomas) {
                            Layouts.tableModelDip.addRow(diploma.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Diplomas found.");
                    }
                }
            }
        });
// Admin Search Diploma Button
        Layouts.searchDipBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchDipFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<DiplomaDomainClass> diplomas = CreationDAO.searchDiploma(keyword);
                    Layouts.tableModelDipAD.setRowCount(0);
                    if (!diplomas.isEmpty()) {
                        for (DiplomaDomainClass diploma : diplomas) {
                            Layouts.tableModelDipAD.addRow(diploma.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Diplomas found.");
                    }
                }
            }
        });
        Layouts.searchLectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchLectFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<LecturerDomainClass> lecturers = CreationDAO.searchLecturers(keyword);
                    Layouts.tableModelLect.setRowCount(0);
                    if (!lecturers.isEmpty()) {
                        for (LecturerDomainClass lecturer : lecturers) {
                            Layouts.tableModelLect.addRow(lecturer.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Lecturers found.");
                    }
                }
            }
        });
        Layouts.searchLectBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchLectFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<LecturerDomainClass> lecturers = CreationDAO.searchLecturers(keyword);
                    Layouts.tableModelLectAD.setRowCount(0);
                    if (!lecturers.isEmpty()) {
                        for (LecturerDomainClass lecturer : lecturers) {
                            Layouts.tableModelLectAD.addRow(lecturer.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Lecturers found.");
                    }
                }
            }
        });
        Layouts.searchMarksBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchMarksFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<StudentMarksDomainClass> marks = CreationDAO.searchStudentMarks(keyword);
                    Layouts.tableModelMarks.setRowCount(0);
                    if (!marks.isEmpty()) {
                        for (StudentMarksDomainClass mark : marks) {
                            Layouts.tableModelMarks.addRow(mark.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Marks found.");
                    }
                }
            }
        });
        Layouts.searchMarksBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchMarksFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<StudentMarksDomainClass> marks = CreationDAO.searchStudentMarks(keyword);
                    Layouts.tableModelMarksAD.setRowCount(0);
                    if (!marks.isEmpty()) {
                        for (StudentMarksDomainClass mark : marks) {
                            Layouts.tableModelMarksAD.addRow(mark.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Marks found.");
                    }
                }
            }
        });
        Layouts.searchResBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchResFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<ResidencesDomainClass> residences = CreationDAO.searchResidences(keyword);
                    Layouts.tableModelRes.setRowCount(0);
                    if (!residences.isEmpty()) {
                        for (ResidencesDomainClass residence : residences) {
                            Layouts.tableModelRes.addRow(residence.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Residences found.");
                    }
                }
            }
        });
        Layouts.searchResBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchResFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<ResidencesDomainClass> residences = CreationDAO.searchResidences(keyword);
                    Layouts.tableModelResAD.setRowCount(0);
                    if (!residences.isEmpty()) {
                        for (ResidencesDomainClass residence : residences) {
                            Layouts.tableModelResAD.addRow(residence.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Residences found.");
                    }
                }
            }
        });

        Layouts.searchStudBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchStudFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<DomainClass> students = CreationDAO.searchStudent(keyword);
                    Layouts.tableModelStud.setRowCount(0);
                    if (!students.isEmpty()) {
                        for (DomainClass student : students) {
                            Layouts.tableModelStud.addRow(student.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Students found.");
                    }
                }
            }
        });
        Layouts.searchStudBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchStudFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<DomainClass> students = CreationDAO.searchStudent(keyword);
                    Layouts.tableModelStudAD.setRowCount(0);
                    if (!students.isEmpty()) {
                        for (DomainClass student : students) {
                            Layouts.tableModelStudAD.addRow(student.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Students found.");
                    }
                }
            }
        });
        Layouts.searchSubBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchSubFld.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<SubjectDomainClass> subjects = CreationDAO.searchSubject(keyword);
                    Layouts.tableModelSub.setRowCount(0);
                    if (!subjects.isEmpty()) {
                        for (SubjectDomainClass subject : subjects) {
                            Layouts.tableModelSub.addRow(subject.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Subjects found.");
                    }
                }
            }
        });
        Layouts.searchSubBtnAD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = Layouts.searchSubFldAD.getText();
                if (keyword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Search field is empty. Please enter a keyword to search.");
                } else {
                    List<SubjectDomainClass> subjects = CreationDAO.searchSubject(keyword);
                    Layouts.tableModelSubAD.setRowCount(0);
                    if (!subjects.isEmpty()) {
                        for (SubjectDomainClass subject : subjects) {
                            Layouts.tableModelSubAD.addRow(subject.toArray());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Subjects found.");
                    }
                }
            }
        });
Layouts.viewStudentCardBtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // Get the current working directory and append the relative path to the image
            String workingDirectory = System.getProperty("user.dir");
            
            // Use a relative path from the working directory to the output image
            String imagePath = workingDirectory + "/src/main/resources/com/mycompany/home/resources/images/output.jpg";
            
            // Load the image directly from the file system
            BufferedImage image = ImageIO.read(new File(imagePath));

            // Create an ImageIcon from the BufferedImage
            ImageIcon imageIcon = new ImageIcon(image);

            // Display the image in a popup dialog
            JOptionPane.showMessageDialog(null, new JLabel(imageIcon), "Student Card", JOptionPane.PLAIN_MESSAGE);

        } catch (Exception er) {
            System.out.println("Error: " + er.getMessage());
        }
    }
});
        
        
        
        bottomPanelLayout();
    }

    public void showMainGUI(JFrame frame) {
        frame.getContentPane().removeAll();  // Clear old content
        frame.add(mainTopPanel, BorderLayout.NORTH);  // Top panel
        frame.add(mainTab, BorderLayout.CENTER);  // Main tab pane
        frame.add(mainBottomPanel, BorderLayout.SOUTH);  // Bottom panel
        frame.revalidate();  // Refresh layout
        frame.repaint();  // Redraw the frame
    }

    private void openStudDialog(DomainClass student) {

        JTextField studentnumFld = new JTextField(20);
        JTextField firstNameFld = new JTextField(20);
        JTextField idNumberFld = new JTextField(20);
        JTextField streetFld = new JTextField(20);
        JTextField suburbFld = new JTextField(20);
        JTextField cityFld = new JTextField(20);
        JTextField postalCodeFld = new JTextField(20);
        JTextField cellNumFld = new JTextField(20);
        JTextField emailAddFld = new JTextField(20);
       // JTextField dipCodeFld = new JTextField(20);
      //  JTextField resIdFld = new JTextField(20);
     //   JTextField roomTypeFld = new JTextField(20);

    //    JTextField campusIdFld = new JTextField(20);
    //    JTextField balanceFld = new JTextField(20);
    JComboBox<String> dipCodeComboBox = new JComboBox<>();
    populateDipCodeComboBox(dipCodeComboBox);

        if (student != null) {
            studentnumFld.setText(String.valueOf(student.getStudent_Num()));
            firstNameFld.setText(student.getFirst_Name());
            idNumberFld.setText(student.getID_Number());
            streetFld.setText(student.getStreet());
            suburbFld.setText(student.getSuburb());
            cityFld.setText(student.getCity());
            postalCodeFld.setText(String.valueOf(student.getPostal_Code()));
            cellNumFld.setText(student.getCell_Num());
            emailAddFld.setText(student.getEmail_Address());
             dipCodeComboBox.removeAllItems();
             dipCodeComboBox.addItem(student.getDip_Code());
        //    dipCodeFld.setText(student.getDip_Code());
        //    resIdFld.setText(student.getID_Number());
        //    roomTypeFld.setText(student.getRoom_Type());
        //    campusIdFld.setText(student.getCampus_ID());
        //    balanceFld.setText(student.getBalance());
        }
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Student Number:"));
        panel.add(studentnumFld);
        panel.add(new JLabel("First Name:"));
        panel.add(firstNameFld);
        panel.add(new JLabel("ID Number:"));
        panel.add(idNumberFld);
        panel.add(new JLabel("Street:"));
        panel.add(streetFld);
        panel.add(new JLabel("Suburb:"));
        panel.add(suburbFld);
        panel.add(new JLabel("City:"));
        panel.add(cityFld);
        panel.add(new JLabel("Postal Code:"));
        panel.add(postalCodeFld);
        panel.add(new JLabel("Cell Number"));
        panel.add(cellNumFld);
        panel.add(new JLabel("Email Address:"));
        panel.add(emailAddFld);
        panel.add(new JLabel("Diploma Code:"));
        panel.add(dipCodeComboBox);
      //  panel.add(new JLabel("Residence ID:"));
      //  panel.add(resIdFld);
      //  panel.add(new JLabel("Room Type:"));
      //  panel.add(roomTypeFld);
      //  panel.add(new JLabel("Campus ID:"));
      //  panel.add(campusIdFld);
      //  panel.add(new JLabel("Balance:"));
      //  panel.add(balanceFld);

        int result = JOptionPane.showConfirmDialog(null, panel, student == null ? "Add Student" : "Update Student", JOptionPane.OK_CANCEL_OPTION);
        //  int result = JOptionPane.showConfirmDialog(null, panel, "Residence", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            
             if (studentnumFld.getText().isEmpty() || firstNameFld.getText().isEmpty() || 
            idNumberFld.getText().isEmpty() || streetFld.getText().isEmpty() ||
            suburbFld.getText().isEmpty() || cityFld.getText().isEmpty() || 
            postalCodeFld.getText().isEmpty() || cellNumFld.getText().isEmpty() ||
            emailAddFld.getText().isEmpty() || dipCodeComboBox.getSelectedItem() == null) {
            
            JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return; // Return if any required field is empty
        }

            DomainClass newStudent = new DomainClass(
                    Integer.parseInt(studentnumFld.getText()),
                    firstNameFld.getText(),
                    idNumberFld.getText(),
                    streetFld.getText(),
                    suburbFld.getText(),
                    cityFld.getText(),
                    Integer.parseInt(postalCodeFld.getText()),
                    cellNumFld.getText(),
                    emailAddFld.getText(),
                    (String)(dipCodeComboBox.getSelectedItem()),
                  //  resIdFld.getText(),
                  //  roomTypeFld.getText(),
                  //  campusIdFld.getText(),
                 //   balanceFld.getText()
                    "NA",
                    "NA",
                    "NA",
                    "NA"
            );

            if (student == null) {
                // Insert a row into the students table
                try {
                    int intStudnum = Integer.parseInt(studentnumFld.getText());
                    int intpostalCode = Integer.parseInt(postalCodeFld.getText());

                    creationDAO.insertStudent(
                            newStudent
                    );
                } catch (SQLException err) {
                    System.out.println("ERROR: " + err);
                }
                JOptionPane.showMessageDialog(null, "This functionality is not available.(Me when i lie)");
            } else {
                try {
                    creationDAO.updateStudent(newStudent, student.getStudent_Num());
                } catch (SQLException err) {
                    System.out.println("ERROR: " + err);
                }
            }
        }
    }

    private void openStudAdminDialog(DomainClass student) {
        JTextField studentnumFld = new JTextField(20);
        JTextField firstNameFld = new JTextField(20);
        JTextField idNumberFld = new JTextField(20);
        JTextField streetFld = new JTextField(20);
        JTextField suburbFld = new JTextField(20);
        JTextField cityFld = new JTextField(20);
        JTextField postalCodeFld = new JTextField(20);
        JTextField cellNumFld = new JTextField(20);
        JTextField emailAddFld = new JTextField(20);
        JTextField dipCodeFld = new JTextField(20);
        JTextField resIdFld = new JTextField(20);
        JTextField roomTypeFld = new JTextField(20);

        JTextField campusIdFld = new JTextField(20);
        JTextField balanceFld = new JTextField(20);

        if (student != null) {
            studentnumFld.setText(String.valueOf(student.getStudent_Num()));
            firstNameFld.setText(student.getFirst_Name());
            idNumberFld.setText(student.getID_Number());
            streetFld.setText(student.getStreet());
            suburbFld.setText(student.getSuburb());
            cityFld.setText(student.getCity());
            postalCodeFld.setText(String.valueOf(student.getPostal_Code()));
            cellNumFld.setText(student.getCell_Num());
            emailAddFld.setText(student.getEmail_Address());
            dipCodeFld.setText(student.getDip_Code());
            resIdFld.setText(student.getID_Number());
            roomTypeFld.setText(student.getRoom_Type());
            campusIdFld.setText(student.getCampus_ID());
            balanceFld.setText(student.getBalance());
        }
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Student Number:"));
        panel.add(studentnumFld);
        panel.add(new JLabel("First Name:"));
        panel.add(firstNameFld);
        panel.add(new JLabel("ID Number:"));
        panel.add(idNumberFld);
        panel.add(new JLabel("Street:"));
        panel.add(streetFld);
        panel.add(new JLabel("Suburb:"));
        panel.add(suburbFld);
        panel.add(new JLabel("City:"));
        panel.add(cityFld);
        panel.add(new JLabel("Postal Code:"));
        panel.add(postalCodeFld);
        panel.add(new JLabel("Cell Number"));
        panel.add(cellNumFld);
        panel.add(new JLabel("Email Address:"));
        panel.add(emailAddFld);
        panel.add(new JLabel("Diploma Code:"));
        panel.add(dipCodeFld);
        panel.add(new JLabel("Residence ID:"));
        panel.add(resIdFld);
        panel.add(new JLabel("Room Type:"));
        panel.add(roomTypeFld);
        panel.add(new JLabel("Campus ID:"));
        panel.add(campusIdFld);
        panel.add(new JLabel("Balance:"));
        panel.add(balanceFld);

        int result = JOptionPane.showConfirmDialog(null, panel, student == null ? "Add Student" : "Update Student", JOptionPane.OK_CANCEL_OPTION);
        //  int result = JOptionPane.showConfirmDialog(null, panel, "Residence", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
                    if (studentnumFld.getText().isEmpty() || firstNameFld.getText().isEmpty() || 
            idNumberFld.getText().isEmpty() || streetFld.getText().isEmpty() ||
            suburbFld.getText().isEmpty() || cityFld.getText().isEmpty() || 
            postalCodeFld.getText().isEmpty() || cellNumFld.getText().isEmpty() ||
            emailAddFld.getText().isEmpty() || dipCodeFld.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

            DomainClass newStudent = new DomainClass(
                    Integer.parseInt(studentnumFld.getText()),
                    firstNameFld.getText(),
                    idNumberFld.getText(),
                    streetFld.getText(),
                    suburbFld.getText(),
                    cityFld.getText(),
                    Integer.parseInt(postalCodeFld.getText()),
                    cellNumFld.getText(),
                    emailAddFld.getText(),
                    dipCodeFld.getText(),
                    resIdFld.getText(),
                    roomTypeFld.getText(),
                    campusIdFld.getText(),
                    balanceFld.getText()
            );

            if (student == null) {
                // Insert a row into the students table
                try {
                    int intStudnum = Integer.parseInt(studentnumFld.getText());
                    int intpostalCode = Integer.parseInt(postalCodeFld.getText());

                    creationDAO.insertStudent(
                            newStudent
                    );
                } catch (SQLException err) {
                    System.out.println("ERROR: " + err);
                }
                JOptionPane.showMessageDialog(null, "This functionality is not available.(Me when i lie)");
            } else {
                try {
                    creationDAO.updateStudent(newStudent, student.getStudent_Num());
                } catch (SQLException err) {
                    System.out.println("ERROR: " + err);
                }
            }
        }
    }

private void openStudResDialog() {
    // Create fields
    JTextField resStdNum = new JTextField(10);
    JComboBox<String> cboRes = new JComboBox<>();
    JComboBox<String> cboCampus = new JComboBox<>();
    JRadioButton snglRadBtn = new JRadioButton("Single Room");
    JRadioButton dblRadBtn = new JRadioButton("Double Room");

    // Panel setup
    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Student Number:"));
    panel.add(resStdNum);
    panel.add(new JLabel("Select Campus:"));
    panel.add(cboCampus);
    panel.add(new JLabel("Select Residence:"));
    panel.add(cboRes);
    panel.add(new JLabel("Select Room Type:"));
    panel.add(snglRadBtn);
    panel.add(new JLabel()); // Empty cell
    panel.add(dblRadBtn);

    // Populate combo boxes with campuses and residences
    try {
        // Fill campus combo box
        List<CampusDomainClass> campuses = creationDAO.getAllCampuses();
        for (CampusDomainClass campus : campuses) {
            cboCampus.addItem(campus.getCampID() + " - " + campus.getLocation());
        }

        // Fill residence combo box
        List<ResidencesDomainClass> residences = creationDAO.getAllResidences();
        for (ResidencesDomainClass residence : residences) {
            cboRes.addItem(residence.getResID() + " - " + residence.getResName());
        }
    } catch (SQLException ex) {
        System.out.println("Error populating combo boxes: " + ex.getMessage());
    }

    // Show dialog
    int result = JOptionPane.showConfirmDialog(null, panel, "Residence", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
                if (resStdNum.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter a valid student number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // Get the entered student number
        int studentNum;
        try {
            studentNum = Integer.parseInt(resStdNum.getText()); // Parse student number from text field
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid student number entered.");
            return;
        }

        // Find the student using the student number
        DomainClass student = null;
        try {
            List<DomainClass> students = creationDAO.getAllStudents();
            for (DomainClass s : students) {
                if (s.getStudent_Num() == studentNum) {
                    student = s;
                    break;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error retrieving student: " + ex.getMessage());
            return;
        }

        if (student == null) {
            JOptionPane.showMessageDialog(null, "Student not found.");
            return;
        }

        // Set the student's current values in the combo boxes and radio buttons
        cboCampus.setSelectedItem(student.getCampus_ID());
        cboRes.setSelectedItem(student.getRes_ID());

        // Set the student's room type
        if (student.getRoom_Type().equalsIgnoreCase("Single Room")) {
            snglRadBtn.setSelected(true);
        } else if (student.getRoom_Type().equalsIgnoreCase("Double Room")) {
            dblRadBtn.setSelected(true);
        }

        // Get the updated values from the user
        String selectedCampus = (String) cboCampus.getSelectedItem();
        String selectedRes = (String) cboRes.getSelectedItem();
        String selectedRoomType = snglRadBtn.isSelected() ? "Single Room" : "Double Room";

        // Extract the IDs from combo box selections
        String campusID = selectedCampus.split(" - ")[0];
        String resID = selectedRes.split(" - ")[0];

        // Update the student information
        try {
            student.setCampus_ID(campusID);
            student.setRes_ID(resID);
            student.setRoom_Type(selectedRoomType);

            // Call the update method to save the changes
            creationDAO.updateStudent(student, studentNum);

            // Notify the user that the update was successful
            JOptionPane.showMessageDialog(null, "Student residence and room type updated successfully!");
        } catch (SQLException ex) {
            System.out.println("Error updating student: " + ex.getMessage());
        }
    }
}


    private void openAdminResDialog(ResidencesDomainClass residence) {

        JTextField ResIdFld = new JTextField(20);
        JTextField ResNamFld = new JTextField(20);
        JTextField CampIdFld = new JTextField(20);
        JTextField DblRoomCostFld = new JTextField(20);
        JTextField SnglRoomCostFld = new JTextField(20);
        JTextField totDblFld = new JTextField(20);
        JTextField totSnglFld = new JTextField(20);
        JTextField availDblFld = new JTextField(20);
        JTextField availSngFld = new JTextField(20);

        if (residence != null) {
            ResIdFld.setText(residence.getResID());
            ResNamFld.setText(residence.getResName());
            CampIdFld.setText(residence.getCampusID());
            DblRoomCostFld.setText(residence.getDBLRoomCost());
            SnglRoomCostFld.setText(residence.getSNGLRoomCost());
            totDblFld.setText(residence.getTOTDBLRooms());
            totSnglFld.setText(residence.getTOTSNGLRooms());
            availDblFld.setText(residence.getAvailDBLRooms());
            availSngFld.setText(residence.getAvailSNGLRooms());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Residence ID:"));
        panel.add(ResIdFld);
        panel.add(new JLabel("Residence Name:"));
        panel.add(ResNamFld);
        panel.add(new JLabel("Campus ID:"));
        panel.add(CampIdFld);
        panel.add(new JLabel("Double Room Cost:"));
        panel.add(DblRoomCostFld);
        panel.add(new JLabel("Single Room Cost:"));
        panel.add(SnglRoomCostFld);
        panel.add(new JLabel("Total Double Rooms:"));
        panel.add(totDblFld);
        panel.add(new JLabel("Total Single Rooms:"));
        panel.add(totSnglFld);
        panel.add(new JLabel("Available Double Rooms:"));
        panel.add(availDblFld);
        panel.add(new JLabel("Available Single Rooms:"));
        panel.add(availSngFld);
        ;
        int result = JOptionPane.showConfirmDialog(null, panel, residence == null ? "Add Residence" : "Update Residence", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
                    if (ResIdFld.getText().isEmpty() || ResNamFld.getText().isEmpty() || CampIdFld.getText().isEmpty() || 
            DblRoomCostFld.getText().isEmpty() || SnglRoomCostFld.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

            // Insert data into the residences table
            ResidencesDomainClass newresidence = new ResidencesDomainClass(
                    ResIdFld.getText(),
                    ResNamFld.getText(),
                    CampIdFld.getText(),
                    DblRoomCostFld.getText(),
                    totDblFld.getText(),
                    availDblFld.getText(),
                    SnglRoomCostFld.getText(),
                    totSnglFld.getText(),
                    availSngFld.getText()
            );
            try {
                if (residence == null) {
                    creationDAO.insertResidences(newresidence);
                } else {
                    creationDAO.updateResidences(newresidence, residence.getResID());
                }
            } catch (SQLException err) {
                System.out.println("ERROR: " + err);
            }

            JOptionPane.showMessageDialog(null, "This functionality is not available.(Me when i lie)");
        }

    }

    // Action listeners with no actual functionality
//        searchButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                JOptionPane.showMessageDialog(null, "Search feature is not available.");
//                backButton.setVisible(false); // Hide back button if no results
//            }
//        });
//
    private void openAdminSubjDialog(SubjectDomainClass subject) {
        //  JTextField titleField = new JTextField(10);
        JTextField subjectField = new JTextField(10);
        JTextField subjectcodeField = new JTextField(10);
        JTextField durationField = new JTextField(10);
        JTextField creditsField = new JTextField(10);
        JTextField amountField = new JTextField(10);

        if (subject != null) {
            subjectField.setText(subject.getSubject());
            subjectcodeField.setText(subject.getSubjectCode());
            durationField.setText(subject.getDuration());
            creditsField.setText(subject.getCredits());
            amountField.setText(subject.getAmount());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2));
        //  panel.add(new JLabel("Title:"));
        //  panel.add(titleField);
        panel.add(new JLabel("Subject:"));
        panel.add(subjectField);
        panel.add(new JLabel("Subject Code:"));
        panel.add(subjectcodeField);
        panel.add(new JLabel("Duration:"));
        panel.add(durationField);
        panel.add(new JLabel("Credits:"));
        panel.add(creditsField);
        panel.add(new JLabel("Amount:"));
        panel.add(amountField);

        //int result = JOptionPane.showConfirmDialog(null, panel, subject == null ? "Add Subject" : "Update Subject", JOptionPane.OK_CANCEL_OPTION);
        int result = JOptionPane.showConfirmDialog(null, panel, subject == null ? "Add Subject" : "Update Subject", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            if (result == JOptionPane.OK_OPTION) {
                        if (subjectField.getText().isEmpty() || subjectcodeField.getText().isEmpty() || durationField.getText().isEmpty() ||
            creditsField.getText().isEmpty() || amountField.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
                // Create a new SubjectDomainClass instance from the form data
                SubjectDomainClass newSubject = new SubjectDomainClass(
                        subjectcodeField.getText(), // Subject Code
                        subjectField.getText(), // Subject
                        durationField.getText(), // Duration
                        creditsField.getText(), // Credits
                        amountField.getText() // Amount
                );
                // Insert data into the residences table
                try {
                    if (subject == null) {
                        // If no subject was passed in, insert a new record
                        creationDAO.insertSubject(newSubject);
                    } else {
                        // If a subject was passed in, update the existing record
                        creationDAO.updateSubject(newSubject, subject.getSubjectCode());
                    }
                } catch (SQLException err) {
                    // Print any SQL errors
                    System.out.println("ERROR: " + err);
                }

                // Show a confirmation message
                JOptionPane.showMessageDialog(null, "This functionality is not available. (Me when I lie)");
            }
        }
    }

    private void openMarksInputDialog(StudentMarksDomainClass studentMarks) {
        // Initialize the text fields
        JTextField term1Field = new JTextField(10);
        JTextField term2Field = new JTextField(10);
        JTextField term3Field = new JTextField(10);
        JTextField term4Field = new JTextField(10);
        JTextField subjectCodeField = new JTextField(10);
        JTextField studentNumField = new JTextField(10);

        // Check if student marks are provided for update, if yes, pre-fill the form
        if (studentMarks != null) {
            subjectCodeField.setText(studentMarks.getSubCode());
            studentNumField.setText(studentMarks.getStudentNum());
            term1Field.setText(studentMarks.getTerm1());
            term2Field.setText(studentMarks.getTerm2());
            term3Field.setText(studentMarks.getTerm3());
            term4Field.setText(studentMarks.getTerm4());
        }

        // Create a panel with a grid layout to hold the form fields
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Subject Code:"));
        panel.add(subjectCodeField);
        panel.add(new JLabel("Student Num:"));
        panel.add(studentNumField);
        panel.add(new JLabel("Term 1:"));
        panel.add(term1Field);
        panel.add(new JLabel("Term 2:"));
        panel.add(term2Field);
        panel.add(new JLabel("Term 3:"));
        panel.add(term3Field);
        panel.add(new JLabel("Term 4:"));
        panel.add(term4Field);

        // Show a confirmation dialog with the form
        int result = JOptionPane.showConfirmDialog(null, panel, studentMarks == null ? "Add Marks" : "Update Marks", JOptionPane.OK_CANCEL_OPTION);

        // If the user clicks OK, process the input
        if (result == JOptionPane.OK_OPTION) {
                    if (subjectCodeField.getText().isEmpty() || studentNumField.getText().isEmpty() || term1Field.getText().isEmpty() ||
            term2Field.getText().isEmpty() || term3Field.getText().isEmpty() || term4Field.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(null, "Please fill in all required fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
            // Create a new StudentMarksDomainClass instance from the form data
            StudentMarksDomainClass newMarks = new StudentMarksDomainClass(
                    subjectCodeField.getText(), // Subject Code
                    studentNumField.getText(), // Student Num
                    term1Field.getText(), // Term 1
                    term2Field.getText(), // Term 2
                    term3Field.getText(), // Term 3
                    term4Field.getText() // Term 4
            );

            // Try to insert or update the marks in the database
            try {
                if (studentMarks == null) {
                    // If no marks were passed in, insert a new record
                    creationDAO.insertStudentMarks(newMarks);
                } else {
                    // If marks were passed in, update the existing record
                    creationDAO.updateStudentMarks(newMarks, studentMarks.getSubCode());
                }
            } catch (SQLException err) {
                // Print any SQL errors
                System.out.println("ERROR: " + err);
            }

            // Show a confirmation message
            JOptionPane.showMessageDialog(null, "This functionality is not available. (Me when I lie)");
        }
    }

    private void openstudSubjDialog(/*Subject subject*/) {
        JComboBox subjDip = new JComboBox();
        JComboBox studAddSubj = new JComboBox();
//
//        if (subject != null) { // Updating existing subject
//            titleField.setText(subject.getTitle());
//            subjectField.setText(subject.getSubject());
//            subjectcodeField.setText(subject.getSubjectCode());
//            durationField.setText(subject.getDuration());
//            creditsField.setText(subject.getCredits());
//            amountField.setText(subject.getAmount());
//            
//        }

        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Select Diploma:"));
        panel.add(subjDip);
        panel.add(new JLabel("Select Subject:"));
        panel.add(studAddSubj);

        //int result = JOptionPane.showConfirmDialog(null, panel, subject == null ? "Add Subject" : "Update Subject", JOptionPane.OK_CANCEL_OPTION);
        int result = JOptionPane.showConfirmDialog(null, panel, "Subject", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            JOptionPane.showMessageDialog(null, "This functionality is not available.");
        }
    }

    private void openCampusDialog(CampusDomainClass campus) {
        // Initialize the text fields
        JTextField locationField = new JTextField(10);
        JTextField campIDField = new JTextField(10);
        JTextField establishedField = new JTextField(10);
        JTextField streetNameField = new JTextField(10);
        JTextField facilitiesField = new JTextField(10);

        // Check if a campus object is provided for update, and pre-fill the form if necessary
        if (campus != null) {
            locationField.setText(campus.getLocation());
            campIDField.setText(campus.getCampID());
            establishedField.setText(campus.getEstablished());
            streetNameField.setText(campus.getStreetName());
            facilitiesField.setText(campus.getFacilities());
        }

        // Create a panel with a grid layout to hold the form fields
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Location:"));
        panel.add(locationField);
        panel.add(new JLabel("Campus ID:"));
        panel.add(campIDField);
        panel.add(new JLabel("Established:"));
        panel.add(establishedField);
        panel.add(new JLabel("Street Name:"));
        panel.add(streetNameField);
        panel.add(new JLabel("Facilities:"));
        panel.add(facilitiesField);

        // Show a confirmation dialog with the form
        int result = JOptionPane.showConfirmDialog(null, panel, campus == null ? "Add Campus" : "Update Campus", JOptionPane.OK_CANCEL_OPTION);

        // If the user clicks OK, process the input
        if (result == JOptionPane.OK_OPTION) {
            // Check for empty fields
            if (locationField.getText().isEmpty() || campIDField.getText().isEmpty() || establishedField.getText().isEmpty()
                    || streetNameField.getText().isEmpty() || facilitiesField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields before proceeding.");
                return;
            }

            // Create a new CampusDomainClass instance from the form data
            CampusDomainClass newCampus = new CampusDomainClass(
                    campIDField.getText(), // Campus ID
                    locationField.getText(), // Location
                    streetNameField.getText(), // Street Name
                    facilitiesField.getText(), // Facilities
                    establishedField.getText() // Established
            );

            // Try to insert or update the campus in the database
            try {
                if (campus == null) {
                    // If no campus was passed in, insert a new campus
                    creationDAO.insertCampus(newCampus);
                } else {
                    // If a campus was passed in, update the existing campus
                    creationDAO.updateCampus(newCampus, campus.getCampID());
                }
            } catch (SQLException err) {
                // Print any SQL errors
                System.out.println("ERROR: " + err);
            }

            // Show a confirmation message
            JOptionPane.showMessageDialog(null, "This functionality is not available. (Me when I lie)");
        }
    }

    private boolean isValidLocation(String location) {
        return location.equalsIgnoreCase("Campus A") || location.equalsIgnoreCase("Campus B") || location.equalsIgnoreCase("Campus C");
    }

//    private Campus getSelectedCampus(int selectedRow) {
//        String location = (String) tableModel.getValueAt(selectedRow, 0);
//        String campID = (String) tableModel.getValueAt(selectedRow, 1);
//        String established = (String) tableModel.getValueAt(selectedRow, 2);
//        String streetName = (String) tableModel.getValueAt(selectedRow, 3);
//        String facilities = (String) tableModel.getValueAt(selectedRow, 4);
//        String campusName = (String) tableModel.getValueAt(selectedRow, 5);
//        return new Campus(location, campID, established, streetName, facilities, campusName);
//    }
//    private void displayAllCampuses() {
//        List<Campus> campuses = database.getCampuses();
//        tableModel.setRowCount(0); // Clear the table
//        for (Campus campus : campuses) {
//            tableModel.addRow(campus.toArray());
//        }
//    }
    private void deleteStudRes() {

    // Create field for student number input
    JTextField resStdNum = new JTextField(10);

    // Panel setup
    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Student Number:"));
    panel.add(resStdNum);

    // Show dialog to enter student number
    int result = JOptionPane.showConfirmDialog(null, panel, "Delete Student Residence Info", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        // Get the entered student number
        int studentNum;
        try {
            studentNum = Integer.parseInt(resStdNum.getText()); // Parse student number from text field
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid student number entered.");
            return;
        }

        // Find the student using the student number
        DomainClass student = null;
        try {
            List<DomainClass> students = creationDAO.getAllStudents();
            for (DomainClass s : students) {
                if (s.getStudent_Num() == studentNum) {
                    student = s;
                    break;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error retrieving student: " + ex.getMessage());
            return;
        }

        if (student == null) {
            JOptionPane.showMessageDialog(null, "Student not found.");
            return;
        }

        // Set Campus_ID, Res_ID, and Room_Type to "NA"
        try {
            student.setCampus_ID("NA");
            student.setRes_ID("NA");
            student.setRoom_Type("NA");

            // Call the update method to save the changes
            creationDAO.updateStudent(student, studentNum);

            // Notify the user that the update was successful
            JOptionPane.showMessageDialog(null, "Student residence info successfully deleted!");
        } catch (SQLException ex) {
            System.out.println("Error updating student: " + ex.getMessage());
        }
    }
}
    
    
    
    private void dipAdminDialog(DiplomaDomainClass diploma) {
        // Initialize the text fields
        JTextField courseOfferingField = new JTextField(10);
        JTextField dipCodeField = new JTextField(10);
        JTextField facultyField = new JTextField(10);
        JTextField campIDField = new JTextField(10);

        // If a diploma object is provided, pre-fill the fields with the existing data
        if (diploma != null) {
            courseOfferingField.setText(diploma.getCourseOffering());
            dipCodeField.setText(diploma.getDipCode());
            facultyField.setText(diploma.getFaculty());
            campIDField.setText(diploma.getCampID());
        }

        // Create a panel and add the fields
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Course Offering:"));
        panel.add(courseOfferingField);
        panel.add(new JLabel("Diploma Code:"));
        panel.add(dipCodeField);
        panel.add(new JLabel("Faculty:"));
        panel.add(facultyField);
        panel.add(new JLabel("Campus ID:"));
        panel.add(campIDField);

        // Show a confirmation dialog with the panel
        int result = JOptionPane.showConfirmDialog(null, panel, diploma == null ? "Add Diploma" : "Update Diploma", JOptionPane.OK_CANCEL_OPTION);

        // If the user clicks OK, process the form data
        if (result == JOptionPane.OK_OPTION) {
            // Check if any fields are empty
            if (courseOfferingField.getText().isEmpty() || dipCodeField.getText().isEmpty() || facultyField.getText().isEmpty() || campIDField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields before proceeding.");
                return;
            }

            // Create a new DiplomaDomainClass object with the form data
            DiplomaDomainClass newDiploma = new DiplomaDomainClass(
                    dipCodeField.getText(), // Diploma Code
                    campIDField.getText(), // Campus ID
                    courseOfferingField.getText(), // Course Offering
                    facultyField.getText() // Faculty
            );

            // Try to insert or update the diploma
            try {
                if (diploma == null) {
                    // Insert a new diploma if no existing diploma is provided
                    creationDAO.insertDiploma(newDiploma);
                } else {
                    // Update the existing diploma using its diploma code
                    creationDAO.updateDiploma(newDiploma, diploma.getDipCode());
                }
            } catch (SQLException err) {
                // Handle any SQL errors
                System.out.println("ERROR: " + err);
            }

            // Show a confirmation message (Your quirky message)
            JOptionPane.showMessageDialog(null, "This functionality is not available. (Me when I lie)");

            // Refresh the diploma display
            displayAllDiploma();
        }
    }

//    private boolean isValidLocation(String location) {
//        return location.equalsIgnoreCase("Diploma A") || location.equalsIgnoreCase("Diploma B") || location.equalsIgnoreCase("Diploma C");
//    }
//    private Diploma getSelectedDiploma(int selectedRow) {
//        String courseOffering = (String) tableModel.getValueAt(selectedRow, 0);
//        String dipCode = (String) tableModel.getValueAt(selectedRow, 1);
//        String faculty = (String) tableModel.getValueAt(selectedRow, 2);
//        String campID = (String) tableModel.getValueAt(selectedRow, 3);
//        return new Diploma(courseOffering, dipCode, faculty, campID);
//    }
    private void displayAllDiploma() {
//        List<Diploma> diplomas = database.getDiploma();
//        tableModel.setRowCount(0); // Clear the table
//        for (Diploma diploma : diplomas) {
//            tableModel.addRow(diploma.toArray());
//        }

    }
private void populateDipCodeComboBox(JComboBox<String> dipCodeComboBox) {
    try {
        // Retrieve all diplomas from the database
        List<DiplomaDomainClass> diplomas = creationDAO.getAllDiplomas();

        // Clear the combo box before adding new items (if needed)
        dipCodeComboBox.removeAllItems();

        // Iterate over the diploma list and add each DipCode to the combo box
        for (DiplomaDomainClass diploma : diplomas) {
            dipCodeComboBox.addItem(diploma.getDipCode());
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error loading DipCodes: " + e.getMessage());
    }
}
    private void lectAdminDialog(LecturerDomainClass lecturer) {
        // Initialize the text fields
        JTextField titleField = new JTextField(10);
        JTextField staffNumberField = new JTextField(10);
        JTextField surnameField = new JTextField(10);
        JTextField firstNameField = new JTextField(10);
        JTextField emailField = new JTextField(10);
        JTextField departmentField = new JTextField(10);
        JTextField diplomacodeField = new JTextField(10);
        JTextField campusField = new JTextField(10);
        JTextField subjectCodeField = new JTextField(10);

        // If a lecturer object is provided, pre-fill the fields with the existing data
        if (lecturer != null) {
            titleField.setText(lecturer.getTitle());
            staffNumberField.setText(lecturer.getStaffNumber());
            surnameField.setText(lecturer.getSurname());
            firstNameField.setText(lecturer.getFirstName());
            emailField.setText(lecturer.getEmail());
            departmentField.setText(lecturer.getDepartment());
            diplomacodeField.setText(lecturer.getDiploma_Code());
            campusField.setText(lecturer.getCampus());
            subjectCodeField.setText(lecturer.getSubjectCode());
        }

        // Create a panel and add the fields
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Staff Number:"));
        panel.add(staffNumberField);
        panel.add(new JLabel("Surname:"));
        panel.add(surnameField);
        panel.add(new JLabel("First Name:"));
        panel.add(firstNameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Department:"));
        panel.add(departmentField);
        panel.add(new JLabel("Diploma Code:"));
        panel.add(diplomacodeField);
        panel.add(new JLabel("Campus:"));
        panel.add(campusField);
        panel.add(new JLabel("Subject Code:"));
        panel.add(subjectCodeField);

        // Show a confirmation dialog with the panel
        int result = JOptionPane.showConfirmDialog(null, panel, lecturer == null ? "Add Lecturer" : "Update Lecturer", JOptionPane.OK_CANCEL_OPTION);

        // If the user clicks OK, process the form data
        if (result == JOptionPane.OK_OPTION) {
            // Check if any fields are empty
            if (titleField.getText().isEmpty() || staffNumberField.getText().isEmpty() || surnameField.getText().isEmpty()
                    || firstNameField.getText().isEmpty() || emailField.getText().isEmpty() || departmentField.getText().isEmpty()
                    || diplomacodeField.getText().isEmpty() || campusField.getText().isEmpty() || subjectCodeField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields before proceeding.");
                return;
            }

            // Validate title
            String title = titleField.getText();
            if (!isValidTitle(title)) {
                JOptionPane.showMessageDialog(null, "Invalid title. Please enter Mr, Mrs, or Ms.");
                return;
            }

            // Validate email
            String email = emailField.getText();
            if (!isValidEmail(email)) {
                JOptionPane.showMessageDialog(null, "Invalid email format.");
                return;
            }

            // Create a new LecturerDomainClass object with the form data
            LecturerDomainClass newLecturer = new LecturerDomainClass(
                    titleField.getText(), // Title
                    staffNumberField.getText(), // Staff Number
                    surnameField.getText(), // Last Name
                    firstNameField.getText(), // First Name
                    emailField.getText(), // Email
                    departmentField.getText(), // Department
                    diplomacodeField.getText(), // Diploma Code
                    campusField.getText(), // Campus
                    subjectCodeField.getText() // Subject Code
            );

            // Try to insert or update the lecturer
            try {
                if (lecturer == null) {
                    // Insert a new lecturer if no existing lecturer is provided
                    creationDAO.insertLecturer(newLecturer);
                } else {
                    // Update the existing lecturer using the staff number or email (your unique identifier)
                    creationDAO.updateLecturer(newLecturer, lecturer.getEmail());
                }
            } catch (SQLException err) {
                // Handle any SQL errors
                System.out.println("ERROR: " + err);
            }

            // Show a confirmation message (Your quirky message)
            JOptionPane.showMessageDialog(null, "This functionality is not available. (Me when I lie)");

            // Refresh the lecturer display
            displayAllLecturers();
        }
    }

    private boolean isValidTitle(String title) {
        return title.equalsIgnoreCase("Mr") || title.equalsIgnoreCase("Mrs") || title.equalsIgnoreCase("Ms");
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return Pattern.matches(emailRegex, email);
    }

//    private Lecturer getSelectedLecturer(int selectedRow) {
//        String title = (String) tableModel.getValueAt(selectedRow, 0);
//        String staffNumber = (String) tableModel.getValueAt(selectedRow, 1);
//        String surname = (String) tableModel.getValueAt(selectedRow, 2);
//        String firstName = (String) tableModel.getValueAt(selectedRow, 3);
//        String email = (String) tableModel.getValueAt(selectedRow, 4);
//        String department = (String) tableModel.getValueAt(selectedRow, 5);
//        String campus = (String) tableModel.getValueAt(selectedRow, 6);
//        String subjectCode = (String) tableModel.getValueAt(selectedRow, 7);
//        return new Lecturer(title, staffNumber, surname, firstName, email, department, campus, subjectCode);
//    }
//    private void displayAllLecturers() {
//        List<Lecturer> lecturers = database.getLecturers();
//        tableModel.setRowCount(0); // Clear the table
//        for (Lecturer lecturer : lecturers) {
//            tableModel.addRow(lecturer.toArray());
//        }
    //   }
    private void displayAllStudents() {
        try {
            List<DomainClass> students = creationDAO.getAllStudents();
            Layouts.tableModelStud.setRowCount(0);
            for (DomainClass student : students) {
                Layouts.tableModelStud.addRow(student.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }
        try {
            List<DomainClass> students = creationDAO.getAllStudents();
            Layouts.tableModelStudAD.setRowCount(0);
            for (DomainClass student : students) {
                Layouts.tableModelStudAD.addRow(student.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }

    }

    private void displayAllSubjects() {
        try {
            // Fetch all subjects from the DAO (Data Access Object)
            List<SubjectDomainClass> subjects = creationDAO.getAllSubjects();

            // Clear the current table rows for Subjects layout
            Layouts.tableModelSub.setRowCount(0);

            // Add each subject's data as a row in the Subjects table model
            for (SubjectDomainClass subject : subjects) {
                Layouts.tableModelSub.addRow(subject.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all subjects for another view/table if needed
            List<SubjectDomainClass> subjects = creationDAO.getAllSubjects();

            // Clear the current table rows for another Subjects layout (e.g., Admin view)
            Layouts.tableModelSubAD.setRowCount(0);

            // Add each subject's data as a row in the Admin Subjects table model
            for (SubjectDomainClass subject : subjects) {
                Layouts.tableModelSubAD.addRow(subject.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }
    }

    private void displayAllLecturers() {
        try {
            // Fetch all lecturers from the DAO (Data Access Object)
            List<LecturerDomainClass> lecturers = creationDAO.getAllLecturers();

            // Clear the current table rows for Lecturers layout
            Layouts.tableModelLect.setRowCount(0);

            // Add each lecturer's data as a row in the Lecturers table model
            for (LecturerDomainClass lecturer : lecturers) {
                Layouts.tableModelLect.addRow(lecturer.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all lecturers for another view/table if needed
            List<LecturerDomainClass> lecturers = creationDAO.getAllLecturers();

            // Clear the current table rows for another Lecturers layout (e.g., Admin view)
            Layouts.tableModelLectAD.setRowCount(0);

            // Add each lecturer's data as a row in the Admin Lecturers table model
            for (LecturerDomainClass lecturer : lecturers) {
                Layouts.tableModelLectAD.addRow(lecturer.toArray());
            }
        } catch (SQLException err) {
            // Handle any SQL errors
            System.out.println("ERROR: " + err);
        }
    }

    private void displayAllDiplomas() {
        try {
            // Fetch all diplomas from the DAO
            List<DiplomaDomainClass> diplomas = creationDAO.getAllDiplomas();

            // Clear the current table rows for Diplomas layout
            Layouts.tableModelDip.setRowCount(0);

            // Add each diploma's data as a row in the Diplomas table model
            for (DiplomaDomainClass diploma : diplomas) {
                Layouts.tableModelDip.addRow(diploma.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all diplomas for another view/table if needed
            List<DiplomaDomainClass> diplomas = creationDAO.getAllDiplomas();

            // Clear the current table rows for Admin Diplomas layout
            Layouts.tableModelDipAD.setRowCount(0);

            // Add each diploma's data as a row in the Admin Diplomas table model
            for (DiplomaDomainClass diploma : diplomas) {
                Layouts.tableModelDipAD.addRow(diploma.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }
    }

    private void displayAllCampuses() {
        try {
            // Fetch all campuses from the DAO
            List<CampusDomainClass> campuses = creationDAO.getAllCampuses();

            // Clear the current table rows for Campuses layout
            Layouts.tableModelCamp.setRowCount(0);

            // Add each campus's data as a row in the Campuses table model
            for (CampusDomainClass campus : campuses) {
                Layouts.tableModelCamp.addRow(campus.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all campuses for another view/table if needed
            List<CampusDomainClass> campuses = creationDAO.getAllCampuses();

            // Clear the current table rows for Admin Campuses layout
            Layouts.tableModelCampAD.setRowCount(0);

            // Add each campus's data as a row in the Admin Campuses table model
            for (CampusDomainClass campus : campuses) {
                Layouts.tableModelCampAD.addRow(campus.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }
    }

    private void displayAllStudentMarks() {
        try {
            // Fetch all student marks from the DAO
            List<StudentMarksDomainClass> studentMarks = creationDAO.getAllStudentMarks();

            // Clear the current table rows for Student Marks layout
            Layouts.tableModelMarks.setRowCount(0);

            // Add each student's marks as a row in the Student Marks table model
            for (StudentMarksDomainClass marks : studentMarks) {
                Layouts.tableModelMarks.addRow(marks.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all student marks for another view/table if needed
            List<StudentMarksDomainClass> studentMarks = creationDAO.getAllStudentMarks();

            // Clear the current table rows for Admin Student Marks layout
            Layouts.tableModelMarksAD.setRowCount(0);

            // Add each student's marks as a row in the Admin Student Marks table model
            for (StudentMarksDomainClass marks : studentMarks) {
                Layouts.tableModelMarksAD.addRow(marks.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }
    }

    private void displayAllResidences() {
        try {
            // Fetch all residences from the DAO
            List<ResidencesDomainClass> residences = creationDAO.getAllResidences();

            // Clear the current table rows for Residences layout
            Layouts.tableModelRes.setRowCount(0);

            // Add each residence's data as a row in the Residences table model
            for (ResidencesDomainClass residence : residences) {
                Layouts.tableModelRes.addRow(residence.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }

        try {
            // Fetch all residences for another view/table if needed
            List<ResidencesDomainClass> residences = creationDAO.getAllResidences();

            // Clear the current table rows for Admin Residences layout
            Layouts.tableModelResAD.setRowCount(0);

            // Add each residence's data as a row in the Admin Residences table model
            for (ResidencesDomainClass residence : residences) {
                Layouts.tableModelResAD.addRow(residence.toArray());
            }
        } catch (SQLException err) {
            System.out.println("ERROR: " + err);
        }
    }

    private CampusDomainClass getSelectedCampus(int selectedRow) {
        String campID = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 0);
        String location = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 1);
        String streetName = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 2);
        String facilities = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 3);
        String established = (String) Layouts.tableModelCampAD.getValueAt(selectedRow, 4);
        return new CampusDomainClass(campID, location, streetName, facilities, established);
    }

    private DiplomaDomainClass getSelectedDiploma(int selectedRow) {
        String dipCode = (String) Layouts.tableModelDipAD.getValueAt(selectedRow, 0);
        String courseOffering = (String) Layouts.tableModelDipAD.getValueAt(selectedRow, 1);
        String faculty = (String) Layouts.tableModelDipAD.getValueAt(selectedRow, 2);
        String campID = (String) Layouts.tableModelDipAD.getValueAt(selectedRow, 3);
        return new DiplomaDomainClass(dipCode, courseOffering, faculty, campID);
    }

    private DomainClass getSelectedStudent(int selectedRow) {
        int studentNum = Integer.parseInt((String) Layouts.tableModelStudAD.getValueAt(selectedRow, 0)); // Student Number
        String firstName = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 1); // First Name
        String idNumber = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 2); // ID Number
        String street = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 3); // Street
        String suburb = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 4); // Suburb
        String city = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 5); // City
        int postalCode = Integer.parseInt((String) Layouts.tableModelStudAD.getValueAt(selectedRow, 6)); // Postal Code
        String cellNum = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 7); // Cell Number
        String emailAddress = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 8); // Email Address
        String dipCode = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 9); // Diploma Code
        String resID = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 10); // Residence ID
        String roomType = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 11); // Room Type
        String campusID = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 12); // Campus ID
        String balance = (String) Layouts.tableModelStudAD.getValueAt(selectedRow, 13); // Balance

        return new DomainClass(studentNum, firstName, idNumber, street, suburb, city, postalCode, cellNum, emailAddress, dipCode, resID, roomType, campusID, balance);
    }

    private StudentMarksDomainClass getSelectedStudentMarks(int selectedRow) {
        String studentNum = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 0);
        String subjectCode = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 1);
        String term1 = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 2);
        String term2 = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 3);
        String term3 = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 4);
        String term4 = (String) Layouts.tableModelMarksAD.getValueAt(selectedRow, 5);
        return new StudentMarksDomainClass(studentNum, subjectCode, term1, term2, term3, term4);
    }

    private LecturerDomainClass getSelectedLecturer(int selectedRow) {
        String title = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 0);
        String staffNumber = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 1);
        String surname = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 2);
        String firstName = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 3);
        String email = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 4);
        String department = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 5);
        String diplomaCode = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 6);
        String campus = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 7);
        String subjectCode = (String) Layouts.tableModelLectAD.getValueAt(selectedRow, 8);
        return new LecturerDomainClass(title, staffNumber, surname, firstName, email, department, diplomaCode, campus, subjectCode);
    }

    private ResidencesDomainClass getSelectedResidences(int selectedRow) {
        String resID = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 0); // Residence ID
        String resName = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 1); // Residence Name
        String campusID = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 2); // Campus ID
        String dblRoomCost = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 3); // Double Room Cost
        String totDblRooms = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 4); // Total Double Rooms
        String availDblRooms = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 5); // Available Double Rooms
        String snglRoomCost = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 6); // Single Room Cost
        String totSnglRooms = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 7); // Total Single Rooms
        String availSnglRooms = (String) Layouts.tableModelResAD.getValueAt(selectedRow, 8); // Available Single Rooms

        return new ResidencesDomainClass(resID, resName, campusID, dblRoomCost, totDblRooms, availDblRooms, snglRoomCost, totSnglRooms, availSnglRooms);
    }

    private SubjectDomainClass getSelectedSubject(int selectedRow) {
        String subjectCode = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 0);
        String subject = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 1);
        String duration = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 2);
        String credits = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 3);
        String amount = (String) Layouts.tableModelSubAD.getValueAt(selectedRow, 4);
        return new SubjectDomainClass(subjectCode, subject, duration, credits, amount);
    }

    private void bottomPanelLayout() {
        JLabel opaLbl = new JLabel("<html><a href =''>OPA</a></html>");
        opaLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel bbLbl = new JLabel("<html><a href=''>BlackBoard</a></html>");
        bbLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel websiteLbl = new JLabel("<html><a href=''>CPUT Website</a></html>");
        websiteLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        JLabel libraryLbl = new JLabel("<html><a href=''>Library</a></html>");
        libraryLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
//
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(smallLogo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        mainBottomPanel.add(linkin, gbc);

        linkin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        linkin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://za.linkedin.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(insta, gbc);

        insta.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        insta.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(fB, gbc);

        fB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        fB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://web.facebook.com/?_rdc=1&_rdr"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
        gbc.gridx = 5;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(twit, gbc);

        twit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        twit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://x.com/?lang=en"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
        gbc.gridx = 6;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(websiteLbl, gbc);

        websiteLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://www.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
        gbc.gridx = 7;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(bbLbl, gbc);

        bbLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://myclassroom.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });
        gbc.gridx = 8;
        gbc.gridy = 0;
        gbc.weightx = 0;  // No horizontal expansion
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        mainBottomPanel.add(opaLbl, gbc);

        opaLbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                try {
                    Desktop.getDesktop().browse(new URI("https://opa.cput.ac.za/"));

                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.home;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author S
 */
public class Layouts {
    //BUTTONS FOR DAYS SON

    // STUDENT PAGE BUTTONS
    public static JButton addStudBtn = new JButton("Add");
    public static JButton updateStudBtn = new JButton("Update");
    public static JButton searchStudBtn = new JButton("Search");
    public static JButton dltStudBtn = new JButton("Delete");
    public static JButton displayStudBtn = new JButton("Display");
    public static JButton viewStudentCardBtn = new JButton("View Student Card");
    public static JTextField searchStudFld;
    public static JTable tableStud;
    public static DefaultTableModel tableModelStud;

    // STUDENT PAGE BUT ADMIN BTNS
    public static JButton addStudBtnAD = new JButton("Add");
    public static JButton updateStudBtnAD = new JButton("Update");
    public static JButton searchStudBtnAD = new JButton("Search");
    public static JButton dltStudBtnAD = new JButton("Delete");
    public static JButton displayStudBtnAD = new JButton("Display");
    public static JTextField searchStudFldAD;
    public static JTable tableStudAD;
    public static DefaultTableModel tableModelStudAD;

    // RES STUDENT
    public static JButton addResBtn = new JButton("Add");
    public static JButton updateResBtn = new JButton("Update");
    public static JButton searchResBtn = new JButton("Search");
    public static JButton dltResBtn = new JButton("Delete");
    public static JButton displayResBtn = new JButton("Display");
    public static JTextField searchResFld;
    public static JTable tableRes;
    public static DefaultTableModel tableModelRes;

    //RES ADMIN
    public static JButton addResBtnAD = new JButton("Add");
    public static JButton updateResBtnAD = new JButton("Update");
    public static JButton searchResBtnAD = new JButton("Search");
    public static JButton dltResBtnAD = new JButton("Delete");
    public static JButton displayResBtnAD = new JButton("Display");
    public static JTextField searchResFldAD;
    public static JTable tableResAD;
    public static DefaultTableModel tableModelResAD;

    //DIPLOMA STUDENT
    public static JButton addDipBtn = new JButton("Add");
    public static JButton updateDipBtn = new JButton("Update");
    public static JButton searchDipBtn = new JButton("Search");
    public static JButton dltDipBtn = new JButton("Delete");
    public static JButton displayDipBtn = new JButton("Display");
    public static JTextField searchDipFld;
    public static JTable tableDip;
    public static DefaultTableModel tableModelDip;
    JComboBox dipStudCampBx;
    JComboBox dipStudBx;

    //DIPLOMA ADMIN
    public static JButton addDipBtnAD = new JButton("Add");
    public static JButton updateDipBtnAD = new JButton("Update");
    public static JButton searchDipBtnAD = new JButton("Search");
    public static JButton dltDipBtnAD = new JButton("Delete");
    public static JButton displayDipBtnAD = new JButton("Display");
    public static JTextField searchDipFldAD;
    public static JTable tableDipAD;
    public static DefaultTableModel tableModelDipAD;
//    CAMPUS STUD
    public static JButton addCampBtn = new JButton("Add");
    public static JButton updateCampBtn = new JButton("Update");
    public static JButton searchCampBtn = new JButton("Search");
    public static JButton dltCampBtn = new JButton("Delete");
    public static JButton displayCampBtn = new JButton("Display");
    public static JTextField searchCampFld;
    public static JTable tableCamp;
    public static DefaultTableModel tableModelCamp;

//  CAMPUS ADMIN
    public static JButton addCampBtnAD = new JButton("Add");
    public static JButton updateCampBtnAD = new JButton("Update");
    public static JButton searchCampBtnAD = new JButton("Search");
    public static JButton dltCampBtnAD = new JButton("Delete");
    public static JButton displayCampBtnAD = new JButton("Display");
    public static JTextField searchCampFldAD;
    public static JTable tableCampAD;
    public static DefaultTableModel tableModelCampAD;
//  SUBJECT STUD MAIN
    public static JButton addSubBtn = new JButton("Add");
    public static JButton updateSubBtn = new JButton("Update");
    public static JButton searchSubBtn = new JButton("Search");
    public static JButton dltSubBtn = new JButton("Delete");
    public static JButton displaySubBtn = new JButton("Display");
    public static JTextField searchSubFld;
    public static JTable tableSub;
    public static DefaultTableModel tableModelSub;
//      SUBJECT ADMIN MAIN
    public static JButton addSubBtnAD = new JButton("Add");
    public static JButton updateSubBtnAD = new JButton("Update");
    public static JButton searchSubBtnAD = new JButton("Search");
    public static JButton dltSubBtnAD = new JButton("Delete");
    public static JButton displaySubBtnAD = new JButton("Display");
    public static JTextField searchSubFldAD;
    public static JTable tableSubAD;
    public static DefaultTableModel tableModelSubAD;

//  SUBJ MARKS STUD
    public static JButton addMarksBtn = new JButton("Add");
    public static JButton updateMarksBtn = new JButton("Update");
    public static JButton searchMarksBtn = new JButton("Search");
    public static JButton dltMarksBtn = new JButton("Delete");
    public static JButton displayMarksBtn = new JButton("Display");
    public static JTextField searchMarksFld;
    public static JTable tableMarks;
    public static DefaultTableModel tableModelMarks;
    JComboBox studMarksBx;

//SUBJ MARKS ADMIN
    public static JButton addMarksBtnAD = new JButton("Add");
    public static JButton updateMarksBtnAD = new JButton("Update");
    public static JButton searchMarksBtnAD = new JButton("Search");
    public static JButton dltMarksBtnAD = new JButton("Delete");
    public static JButton displayMarksBtnAD = new JButton("Display");
    public static JTextField searchMarksFldAD;
    public static JTable tableMarksAD;
    public static DefaultTableModel tableModelMarksAD;

//  LECTURER STUD
    public static JButton addLectBtn = new JButton("Add");
    public static JButton updateLectBtn = new JButton("Update");
    public static JButton searchLectBtn = new JButton("Search");
    public static JButton dltLectBtn = new JButton("Delete");
    public static JButton displayLectBtn = new JButton("Display");
    public static JTextField searchLectFld;
    public static JTable tableLect;
    public static DefaultTableModel tableModelLect;

// LECTURER ADMIN
    public static JButton addLectBtnAD = new JButton("Add");
    public static JButton updateLectBtnAD = new JButton("Update");
    public static JButton searchLectBtnAD = new JButton("Search");
    public static JButton dltLectBtnAD = new JButton("Delete");
    public static JButton displayLectBtnAD = new JButton("Display");
    public static JTextField searchLectFldAD;
    public static JTable tableLectAD;
    public static DefaultTableModel tableModelLectAD;

    public JPanel studStudentPanelLayout() {
        JPanel studStud = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchStudFld = new JTextField(20);

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchStudFld);
        controlPanel.add(searchStudBtn);
        controlPanel.add(addStudBtn);    
        controlPanel.add(updateStudBtn);
        controlPanel.add(displayStudBtn);
        controlPanel.add(dltStudBtn);
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(new JLabel());
        controlPanel.add(viewStudentCardBtn);

        studStud.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Student_Num", "First_Name", "ID_Number", "Street", "Suburb", "City", "Postal_Code", "Cell_Num", "Email_Address", "Dip_Code", "Res_ID", "Room_Type", "Campus_ID", "Balance"};
        tableModelStud = new DefaultTableModel(columnNames, 0);
        tableStud = new JTable(tableModelStud);
        tableStud.setBackground(Color.WHITE);
        studStud.add(new JScrollPane(tableStud), BorderLayout.CENTER);
 
        return studStud;

    }

    public JPanel adminStudentLayout() {
        JPanel adminStud = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchStudFldAD = new JTextField(20);
        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchStudFldAD);
        controlPanel.add(searchStudBtnAD);
        controlPanel.add(addStudBtnAD);
        controlPanel.add(updateStudBtnAD);
        controlPanel.add(displayStudBtnAD);
        controlPanel.add(dltStudBtnAD);
        controlPanel.add(backButton);

        adminStud.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Student_Num", "First_Name", "ID_Number", "Street", "Suburb", "City", "Postal_Code", "Cell_Num", "Email_Address", "Dip_Code", "Res_ID", "Room_Type", "Campus_ID", "Balance"};
        tableModelStudAD = new DefaultTableModel(columnNames, 0);
        tableStudAD = new JTable(tableModelStudAD);
        adminStud.add(new JScrollPane(tableStudAD), BorderLayout.CENTER);
        return adminStud;
    }

    public JPanel studResLayout() {

        JPanel studRes = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchResFld = new JTextField(20);

        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchResFld);
        controlPanel.add(searchResBtn);
        controlPanel.add(addResBtn);
        
        controlPanel.add(updateResBtn);
        controlPanel.add(displayResBtn);
        controlPanel.add(dltResBtn);
        controlPanel.add(backButton);

        studRes.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Residence ID", "Residence Name", "Campus ID", "Double Room Cost", "Single Room Cost", "Total Double Rooms", "Total Single Rooms", "Available Double Rooms", "Available Single Rooms"};
        tableModelRes = new DefaultTableModel(columnNames, 0);
        tableRes = new JTable(tableModelRes);
        tableRes.setBackground(Color.WHITE);
        studRes.add(new JScrollPane(tableRes), BorderLayout.CENTER);

        return studRes;
    }

    public JPanel adminResLayout() {
        JPanel adminRes = new JPanel(new BorderLayout());

  
        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchResFldAD = new JTextField(20);
        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchResFldAD);
        controlPanel.add(searchResBtnAD);
        controlPanel.add(addResBtnAD);
        
        controlPanel.add(updateResBtnAD);
        controlPanel.add(displayResBtnAD);
        controlPanel.add(dltResBtnAD);
        controlPanel.add(backButton);

        adminRes.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Residence ID", "Residence Name", "Campus ID", "Double Room Cost", "Single Room Cost", "Total Double Rooms", "Total Single Rooms", "Available Double Rooms", "Available Single Rooms"};
        tableModelResAD = new DefaultTableModel(columnNames, 0);
        tableResAD = new JTable(tableModelResAD);
        tableResAD.setBackground(Color.WHITE);
        adminRes.add(new JScrollPane(tableResAD), BorderLayout.CENTER);

        return adminRes;
    }

    public JPanel adminSubjLayout() {
        JPanel adminSubj = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchSubFldAD= new JTextField(20);
        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchSubFldAD);
        controlPanel.add(searchSubBtnAD);
        controlPanel.add(addSubBtnAD);
        
        controlPanel.add(updateSubBtnAD);
        controlPanel.add(displaySubBtnAD);
        controlPanel.add(dltSubBtnAD);

        controlPanel.add(backButton);

        adminSubj.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Subject Code","Subject",  "Duration", "Credits", "Amount"};
       tableModelSubAD = new DefaultTableModel(columnNames, 0);
        tableSubAD = new JTable(tableModelSubAD);
        tableSubAD.setBackground(Color.WHITE);
        adminSubj.add(new JScrollPane(tableSubAD), BorderLayout.CENTER);

        return adminSubj;
    }

    public JPanel adminMarksLayout() {

        JPanel marksAdminSubj = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchMarksFldAD = new JTextField(20);
        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchMarksFldAD);
        controlPanel.add(searchMarksBtnAD);
        controlPanel.add(addMarksBtnAD);
        
        controlPanel.add(updateMarksBtnAD);
        controlPanel.add(displayMarksBtnAD);
        controlPanel.add(dltMarksBtnAD);
        controlPanel.add(backButton);

        marksAdminSubj.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Sub_Code", "Student_Num", "Term1", "Term2", "Term3", "Term4"};
        tableModelMarksAD = new DefaultTableModel(columnNames, 0);
        tableMarksAD = new JTable(tableModelMarksAD);
        marksAdminSubj.add(new JScrollPane(tableMarksAD), BorderLayout.CENTER);

        return marksAdminSubj;
    }

    public JPanel studMarksLayout() {
        JPanel marksStudSubj = new JPanel(new BorderLayout());

        JButton backButton;
            
     studMarksBx = new JComboBox();

        JPanel controlPanel = new JPanel();
        searchMarksFld= new JTextField(20);
        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchMarksFld);
        controlPanel.add(searchMarksBtn);
      //  controlPanel.add(studMarksBx);
        controlPanel.add(displayMarksBtn);

        marksStudSubj.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Sub_Code", "Student_Num", "Term1", "Term2", "Term3", "Term4"};
        tableModelMarks = new DefaultTableModel(columnNames, 0);
        tableMarks= new JTable(tableModelMarks);
        marksStudSubj.add(new JScrollPane(tableMarks), BorderLayout.CENTER);
        return marksStudSubj;

    }

    public JPanel studSubjLayout() {
        JPanel studSubj = new JPanel(new BorderLayout());

        JButton backButton;

//        JPanel centerPanel = new JPanel();
//        centerPanel.setLayout(new BorderLayout());
        JPanel controlPanel = new JPanel();
        searchSubFld = new JTextField(20);
        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchSubFld);
        controlPanel.add(searchSubBtn);
      //  controlPanel.add(addSubBtn);
        controlPanel.add(displaySubBtn);

        studSubj.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = { "Subject Code","Subject",  "Duration", "Credits", "Amount"};
        tableModelSub = new DefaultTableModel(columnNames, 0);
        tableSub = new JTable(tableModelSub);
        studSubj.add(new JScrollPane(tableSub), BorderLayout.CENTER);
        return studSubj;
    }

    public JPanel studCampusLayout() {
        JPanel studCampus = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());

        JPanel controlPanel = new JPanel();
        searchCampFld = new JTextField(20);

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchCampFld);
        controlPanel.add(searchCampBtn);
        controlPanel.add(displayCampBtn);

        studCampus.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = { "CampID","Location", "Street Name", "Facilities", "Established"};
        tableModelCamp = new DefaultTableModel(columnNames, 0);
        tableCamp = new JTable(tableModelCamp);
        studCampus.add(new JScrollPane(tableCamp), BorderLayout.CENTER);
        return studCampus;

    }

    public JPanel adminCampusLayout() {
        JPanel adminCampus = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());

        JPanel controlPanel = new JPanel();
        searchCampFldAD = new JTextField(20);

        backButton = new JButton("Back");

        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchCampFldAD);
        controlPanel.add(searchCampBtnAD);
        controlPanel.add(addCampBtnAD);
        
        controlPanel.add(updateCampBtnAD);
        controlPanel.add(displayCampBtnAD);
        controlPanel.add(dltCampBtnAD);
        controlPanel.add(backButton);

        adminCampus.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"CampID","Location", "Street Name", "Facilities", "Established"};
        tableModelCampAD = new DefaultTableModel(columnNames, 0);
        tableCampAD = new JTable(tableModelCampAD);
        adminCampus.add(new JScrollPane(tableCampAD), BorderLayout.CENTER);

        return adminCampus;

    }

    public JPanel studDipLayout() {

        JPanel studDip = new JPanel(new BorderLayout());

        dipStudCampBx = new JComboBox();
        dipStudBx = new JComboBox();

        JPanel controlPanel = new JPanel();
        searchDipFld = new JTextField(20);

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchDipFld);
        controlPanel.add(searchDipBtn);
      //controlPanel.add(dipStudCampBx);
      //controlPanel.add(dipStudBx);
        controlPanel.add(displayDipBtn);

        studDip.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Dip Code","Camp ID" ,"Course Offering","Faculty"};
        tableModelDip = new DefaultTableModel(columnNames, 0);
        tableDip = new JTable(tableModelDip);
        studDip.add(new JScrollPane(tableDip), BorderLayout.CENTER);
        return studDip;

    }

    public JPanel adminDipLayout() {
        // private final DiplomaDatabase database;
        JPanel adminDip = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchDipFldAD = new JTextField(20);

        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchDipFldAD);
        controlPanel.add(searchDipBtnAD);
        controlPanel.add(addDipBtnAD);
        
        controlPanel.add(updateDipBtnAD);
        controlPanel.add(displayDipBtnAD);
        controlPanel.add(dltDipBtnAD);
        controlPanel.add(backButton);

        adminDip.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = { "Dip Code","Camp ID" ,"Course Offering","Faculty" };
        tableModelDipAD = new DefaultTableModel(columnNames, 0);
        tableDipAD = new JTable(tableModelDipAD);
        adminDip.add(new JScrollPane(tableDipAD), BorderLayout.CENTER);

        return adminDip;

    }

    public JPanel studLectLayout() {
        JPanel studLect = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchLectFld = new JTextField(20);

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchLectFld);
        controlPanel.add(searchLectBtn);

        controlPanel.add(displayLectBtn);

        studLect.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Title", "Staff Number", "Surname", "First Name", "Email", "Department","Diploma Code" ,"Campus", "Subject Code"};
        tableModelLect = new DefaultTableModel(columnNames, 0);
        tableLect = new JTable(tableModelLect);
        studLect.add(new JScrollPane(tableLect), BorderLayout.CENTER);
        return studLect;
    }

    public JPanel adminLectLayout() {
        JPanel adminLect = new JPanel(new BorderLayout());

        JButton backButton;

        JPanel controlPanel = new JPanel();
        searchLectFldAD = new JTextField(20);

        backButton = new JButton("Back");
        backButton.setVisible(false); // Initially hidden

        controlPanel.add(new JLabel("Search:"));
        controlPanel.add(searchLectFldAD);
        controlPanel.add(searchLectBtnAD);
        controlPanel.add(addLectBtnAD);
        
        controlPanel.add(updateLectBtnAD);
        controlPanel.add(displayLectBtnAD);
        controlPanel.add(dltLectBtnAD);
        controlPanel.add(backButton);

        adminLect.add(controlPanel, BorderLayout.NORTH);

        String[] columnNames = {"Title", "Staff Number", "Surname", "First Name", "Email", "Department","Diploma Code" ,"Campus", "Subject Code"};
        tableModelLectAD = new DefaultTableModel(columnNames, 0);
        tableLectAD = new JTable(tableModelLectAD);
        adminLect.add(new JScrollPane(tableLectAD), BorderLayout.CENTER);

        return adminLect;
    }
}